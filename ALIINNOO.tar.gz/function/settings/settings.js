import { watchFile, unwatchFile } from 'fs'
import fs from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

/*
Setting
*/
global.setting = {
 clearSesi: false, // trash cleaner sessions 
 clearTmp: true, // tmp trash cleaner
 addReply: true, // create with thumbnail in message
 idgc: '120363315668824185@g.us' // id gc buat join only
 }

global.info = {
 nomerbot : '212605784394',
 pairingNumber : '212644250242',
 figlet: 'silanalite', // create a start console display
 nomorwa : '212619922544',
 nameown : 'NOUREDDINE',
 nomerown : '212710643142',
 packname : 'sticker by ',
 author : 'SILANA AI',
 namebot : '乂 ALINO AI',
 wm : 'ALINO TV.',
 stickpack : 'Whatsapp',
 stickauth : 'ALINO TV',
 jid: '@s.whatsapp.net'
}

// Thumbnail 
global.media = {
 ppKosong : 'https://files.catbox.moe/3ovift.jpg',
 didyou : 'https://files.catbox.moe/3ovift.jpg',
 rulesBot : 'https://files.catbox.moe/3ovift.jpg',
 thumbnail : 'https://files.catbox.moe/3ovift.jpg',
 thumb : 'https://files.catbox.moe/3ovift.jpg',
 logo : 'https://files.catbox.moe/3ovift.jpg',
 unReg : 'https://files.catbox.moe/3ovift.jpg',
 registrasi : 'https://files.catbox.moe/3ovift.jpg',
 confess : 'https://files.catbox.moe/3ovift.jpg',
 access : 'https://files.catbox.moe/3ovift.jpg',
 tqto : 'https://files.catbox.moe/3ovift.jpg',
 spotify : 'https://files.catbox.moe/3ovift.jpg',
 weather : 'https://files.catbox.moe/3ovift.jpg',
 gempaUrl : 'https://files.catbox.moe/3ovift.jpg',
 akses : 'https://files.catbox.moe/3ovift.jpg',
 wel : 'https://files.catbox.moe/3ovift.jpg',
 good : 'https://files.catbox.moe/3ovift.jpg',
 sound: 'https://pomf2.lain.la/f/ymca9u8.opus'
}
// Social media
global.url = {
 sig: 'https://instagram.com/amin1_tech1',
 sgh:  'https://instagram.com/amin1_tech1',
 sgc: 'https://whatsapp.com/channel/0029VaX4b6J7DAWq3Hhu01A'
}
// Donasi
global.payment = {
 psaweria: 'https://saweria.co/mamad',
 ptrakterr: '-',
 pdana: '0823427570'
}
// Info Wait
global.msg = {
 wait: '⏱️ *يرجى التحلي بالصبر*\n\> نحاول تلبية طلبكم ...',
 eror: '🤖 *Information Bot*\n\> Sorry for the inconvenience in using *Silana Ai*. There was an error in the system while executing the command.'
}
 
// api_id web suntik
global.apiId = {
 smm: '4524',
 lapak: '300672'
}

// Apikey
global.api = {
 user: '-', // api_id antinsfw 
 screet: '-', // api_screet nsfw after that, replace it yourself
 uptime: '-',
 xyro: '-',
 lol: 'GataDiosV2',
 smm: '-',
 lapak: '-',
 prodia: '-',
 bing: '1-HLkal9xPklSXn8H_NYBhugb9UnCJKJEzQp4Rk_PxP4xxBCqtm_Os-93cXF8mtFeqde_ZGjnx2C1MM4PCS0gH8mzdX5tJ5aoaDC4G0VruZATWvvOQlHs2UBDNID5PR4MtskWzX69idiBidGDqVwfNBNZYgqb3cgqkLbyEeZnWHxxrhO3es3O8YOI5wd8Y0a31_OiLKTAzwS1ba-wvcBP9khAHrUkuQpzXuoybpwfwpQ'

}
global.APIs = {
    xyro: "https://api.xyroinee.xyz",
    nightTeam: "https://api.tioxy.my.id",
    lol: "https://api.lolhumaan.xyz",
    smm: "https://smmnusantara.id",
    lapak: "https://panel.lapaksosmed.com"
}

//Apikey
global.APIKeys = {
    "https://api.xyroinee.xyz": "vRFLiyLPWu",
    "https://api.lolhumaan.xyz": "GataDiosV2"
}

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'settings.js'"))
  import(`${file}?update=${Date.now()}`)
})