// -*- coding: utf-8 -*-
import { exec } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);

// مسار سكريبت بايثون لإدارة القنوات
const PYTHON_SCRIPT_PATH = '/home/container/channel_manager.py';

// لتخزين حالة المحادثة لكل مستخدم
const userState = {}; // { userId: { step: 'awaiting_country'/'awaiting_channel', country: 'selected_country' } }

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const userId = m.sender;
    const args = text.trim().split(/ +/);

    try {
        // بدء المحادثة عند استخدام الأمر .قنوات
        if (command === 'قنوات' && !userState[userId]) {
            m.reply('⏳ جاري جلب قائمة الدول، يرجى الانتظار...');
            const { stdout, stderr } = await execPromise(`python3.11 ${PYTHON_SCRIPT_PATH} get_countries`);
            if (stderr) {
                console.error(`Python Error (get_countries): ${stderr}`);
                throw new Error('حدث خطأ أثناء جلب قائمة الدول.');
            }

            const countriesResult = JSON.parse(stdout);
            if (countriesResult.error) {
                throw new Error(countriesResult.error);
            }
            const countries = countriesResult.result;

            if (!countries || countries.length === 0) {
                return m.reply('⚠️ لم يتم العثور على دول متاحة.');
            }

            // تنسيق قائمة الدول
            let countryListText = '🌍 *اختر الدولة التي تريد عرض قنواتها:*

';
            countries.forEach((country, index) => {
                countryListText += `${index + 1}. ${country}
`;
            });
            countryListText += '
🔢 يرجى الرد برقم الدولة أو اسمها.';

            // تخزين حالة المستخدم
            userState[userId] = { step: 'awaiting_country', countries };
            return m.reply(countryListText);
        }

        // التعامل مع رد المستخدم (اختيار الدولة أو القناة)
        if (userState[userId]) {
            const state = userState[userId];

            // إذا كان المستخدم في خطوة اختيار الدولة
            if (state.step === 'awaiting_country') {
                let selectedCountry = null;
                const input = text.trim();
                const inputNumber = parseInt(input);

                // التحقق مما إذا كان الإدخال رقماً
                if (!isNaN(inputNumber) && inputNumber > 0 && inputNumber <= state.countries.length) {
                    selectedCountry = state.countries[inputNumber - 1];
                } else {
                    // البحث عن اسم الدولة (مع تجاهل حالة الأحرف)
                    const foundCountry = state.countries.find(c => c.toLowerCase() === input.toLowerCase());
                    if (foundCountry) {
                        selectedCountry = foundCountry;
                    }
                }

                if (!selectedCountry) {
                    return m.reply('⚠️ اختيار غير صالح. يرجى الرد برقم الدولة الصحيح أو اسمها من القائمة.');
                }

                m.reply(`⏳ جاري جلب قنوات دولة *${selectedCountry}*...`);
                const { stdout, stderr } = await execPromise(`python3.11 ${PYTHON_SCRIPT_PATH} get_channels "${selectedCountry}"`);
                if (stderr) {
                    console.error(`Python Error (get_channels): ${stderr}`);
                    throw new Error('حدث خطأ أثناء جلب قائمة القنوات.');
                }

                const channelsResult = JSON.parse(stdout);
                if (channelsResult.error) {
                    throw new Error(channelsResult.error);
                }
                const channels = channelsResult.result;

                if (!channels || channels.length === 0) {
                    delete userState[userId]; // إنهاء الحالة
                    return m.reply(`⚠️ لم يتم العثور على قنوات لدولة *${selectedCountry}*.`);
                }

                // تنسيق قائمة القنوات
                let channelListText = `📺 *قنوات دولة ${selectedCountry}:*

`;
                // عرض عدد محدود من القنوات في كل مرة لتجنب الرسائل الطويلة جداً
                const maxChannelsToShow = 50; 
                const channelsToShow = channels.slice(0, maxChannelsToShow);
                channelsToShow.forEach((channel, index) => {
                    channelListText += `${index + 1}. ${channel}
`;
                });
                if (channels.length > maxChannelsToShow) {
                    channelListText += `\n... وأكثر (${channels.length - maxChannelsToShow} قناة أخرى)`;
                }
                channelListText += '\n\n🔢 يرجى الرد برقم القناة أو اسمها للحصول على الشعار.';

                // تحديث حالة المستخدم
                userState[userId] = { step: 'awaiting_channel', country: selectedCountry, channels };
                return m.reply(channelListText);
            }

            // إذا كان المستخدم في خطوة اختيار القناة
            if (state.step === 'awaiting_channel') {
                let selectedChannel = null;
                const input = text.trim();
                const inputNumber = parseInt(input);

                // التحقق مما إذا كان الإدخال رقماً
                if (!isNaN(inputNumber) && inputNumber > 0 && inputNumber <= state.channels.length) {
                    selectedChannel = state.channels[inputNumber - 1];
                } else {
                    // البحث عن اسم القناة (مع تجاهل حالة الأحرف)
                    // نستخدم find للبحث عن تطابق قريب (يبدأ بالاسم أو يحتوي عليه)
                    const foundChannel = state.channels.find(c => 
                        c.toLowerCase() === input.toLowerCase() || 
                        c.toLowerCase().startsWith(input.toLowerCase())
                    );
                    if (foundChannel) {
                        selectedChannel = foundChannel;
                    } else {
                         // محاولة بحث أكثر تساهلاً (يحتوي على الكلمة)
                         const lowerInput = input.toLowerCase();
                         const partialMatch = state.channels.find(c => c.toLowerCase().includes(lowerInput));
                         if(partialMatch) selectedChannel = partialMatch;
                    }
                }

                if (!selectedChannel) {
                    return m.reply('⚠️ اختيار غير صالح. يرجى الرد برقم القناة الصحيح أو اسمها من القائمة.');
                }

                m.reply(`⏳ جاري البحث عن شعار قناة *${selectedChannel}* في *${state.country}*...`);
                const { stdout, stderr } = await execPromise(`python3.11 ${PYTHON_SCRIPT_PATH} find_logo_file "${state.country}" "${selectedChannel}"`);
                if (stderr) {
                    console.error(`Python Error (find_logo_file): ${stderr}`);
                    throw new Error('حدث خطأ أثناء البحث عن الشعار.');
                }

                const logoResult = JSON.parse(stdout);
                if (logoResult.error) {
                    throw new Error(logoResult.error);
                }
                const logoPath = logoResult.result;

                // حذف حالة المستخدم بعد الانتهاء
                delete userState[userId];

                if (logoPath) {
                    // إرسال الشعار كصورة
                    await conn.sendFile(m.chat, logoPath, `${selectedChannel}.png`, `🖼️ شعار قناة: *${selectedChannel}*\n🌍 الدولة: *${state.country}*`, m);
                } else {
                    return m.reply(`⚠️ لم يتم العثور على شعار لقناة *${selectedChannel}* في *${state.country}*.`);
                }
            }
        }
        // إذا لم يكن الأمر .قنوات ولا يوجد حالة للمستخدم، تجاهل الرسالة
        // (هذا يمنع البوت من الرد على كل رسالة عادية)

    } catch (error) {
        console.error('Handler Error:', error);
        // حذف حالة المستخدم عند حدوث خطأ
        if (userState[userId]) {
            delete userState[userId];
        }
        m.reply(`❌ حدث خطأ: ${error.message}`);
    }
};

// تحديد الأوامر التي يستجيب لها هذا المعالج
handler.command = /^(قنوات)$/i; // يستجيب فقط لأمر .قنوات
handler.all = async (m, { conn }) => { // يستجيب لجميع الرسائل للتحقق من الحالة
    const userId = m.sender;
    // التحقق مما إذا كان المستخدم في حالة محادثة نشطة
    if (userState[userId]) {
        // استدعاء المعالج الرئيسي للتعامل مع الرد
        // تمرير command وهمي لضمان عدم إعادة بدء المحادثة
        await handler(m, { conn, text: m.text, usedPrefix: '.', command: 'response' }); 
        return true; // منع المعالجات الأخرى من التعامل مع هذه الرسالة
    }
    return false; // السماح للمعالجات الأخرى بالعمل
};

handler.help = ['صور_قنوات'];
handler.tags = ['tools'];

export default handler;

