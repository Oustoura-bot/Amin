import moment from 'moment-timezone';
import fs from 'fs'; // Needed for subscription check

// --- Subscription Check Logic (Copied from fblive_enhanced_v2.js) --- START ---
const SUBS_FILE = './subscriptions.json'; // Path to the subscription file

function readSubscriptions() {
    try {
        if (fs.existsSync(SUBS_FILE)) {
            const data = fs.readFileSync(SUBS_FILE, 'utf8');
            return JSON.parse(data);
        } else {
            return {};
        }
    } catch (error) {
        console.error("Error reading subscriptions file:", error);
        return {};
    }
}

function hasValidSubscription(userId) {
    const ownerJids = (global.owner || []).map(v => String(v).replace(/[^0-9]/g, '') + '@s.whatsapp.net');
    if (ownerJids.includes(userId)) {
        return { valid: true, isOwner: true };
    }

    const subscriptions = readSubscriptions();
    if (!subscriptions[userId] || !subscriptions[userId].expiry) {
        return { valid: false, reason: 'No subscription' };
    }

    const expiryDate = moment(subscriptions[userId].expiry);
    const now = moment();

    if (expiryDate.isBefore(now)) {
        return { valid: false, reason: 'Expired' };
    }

    return { valid: true, expiryDate: expiryDate };
}
// --- Subscription Check Logic --- END ---

let handler = async (m, { conn, command }) => {
    let userId = m.sender;

    // --- Subscription Check ---
    const subscriptionStatus = hasValidSubscription(userId);
    if (!subscriptionStatus.valid && !subscriptionStatus.isOwner) { // Allow owner bypass
        if (subscriptionStatus.reason === 'Expired') {
            return m.reply("*╔═════ 🚫 انتهى الاشتراك ═════╗*\n*║* عذراً، اشتراكك في خدمة البث قد انتهى.\n*║* يرجى تجديد اشتراكك للمتابعة.\n*╚════════════════════════╝*");
        }
        return m.reply("*╔═════ 🔒 صلاحية مطلوبة ═════╗*\n*║* ليس لديك الصلاحية لاستخدام هذا الأمر.\n*║* يتطلب اشتراكاً نشطاً أو أن تكون المالك.\n*╚════════════════════════╝*");
    }
    // --- End Subscription Check ---

    // Access the global stream store
    const streams = global.runningFbStreams || {};
    const allStreamIds = Object.keys(streams);

    // Filter streams started by the current user
    const userStreamIds = allStreamIds.filter(id => streams[id]?.startedBy === userId);

    if (userStreamIds.length === 0) {
        return m.reply("✨ *لم تقم ببدء أي عمليات بث مباشر نشطة حاليًا.* ✨");
    }

    let replyText = `*╔═════ 📡 بثوثك النشطة (${userStreamIds.length}) ═════╗*
*
*`;

    let count = 1;
    for (const streamId of userStreamIds) {
        const streamInfo = streams[streamId];
        const startTime = streamInfo.startTime || Date.now(); // Fallback
        const duration = moment.duration(Date.now() - startTime);
        const durationFormatted = `${Math.floor(duration.asHours())} س ${duration.minutes()} د ${duration.seconds()} ث`;
        // No need to display 'startedBy' as it's always the user themselves

        replyText += `*║═══  البث ${count} (${streamId}) ═══*
`;
        replyText += `*║* 🆔 *المعرف:* 
*║*    └ ${streamId}
`;
        replyText += `*║* 🔗 *المصدر:* 
*║*    └ ${streamInfo.sourceUrl || 'غير محدد'}
`;
        replyText += `*║* ⏳ *المدة:* 
*║*    └ ${durationFormatted}
`;
        replyText += `*║* 🔄 *محاولات إعادة التشغيل:* ${streamInfo.retries || 0}
`;
        replyText += `*║------------------------------------*
`;
        count++;
    }

    replyText += `*╚════════════════════════╝*`;

    // Reply to the user
    conn.reply(m.chat, replyText.trim(), m);

};

handler.help = ["mystreams"];
handler.tags = ["streaming"]; // Tag for regular users
handler.command = ["mystreams", "بثوثي"];
// No owner restriction here, subscription check handles access

export default handler;

