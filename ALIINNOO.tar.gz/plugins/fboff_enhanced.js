import fs from 'fs'; // Needed for subscription check
import moment from 'moment-timezone'; // Needed for subscription check

// --- Subscription Check Logic (Copied from fblive_enhanced_v2.js) --- START ---
const SUBS_FILE = './subscriptions.json'; // Path to the subscription file

function readSubscriptions() {
    try {
        if (fs.existsSync(SUBS_FILE)) {
            const data = fs.readFileSync(SUBS_FILE, 'utf8');
            return JSON.parse(data);
        } else {
            return {};
        }
    } catch (error) {
        console.error("Error reading subscriptions file:", error);
        return {};
    }
}

function hasValidSubscription(userId) {
    const ownerJids = (global.owner || []).map(v => String(v).replace(/[^0-9]/g, '') + '@s.whatsapp.net');
    if (ownerJids.includes(userId)) {
        return { valid: true, isOwner: true };
    }

    const subscriptions = readSubscriptions();
    if (!subscriptions[userId] || !subscriptions[userId].expiry) {
        return { valid: false, reason: 'No subscription' };
    }

    const expiryDate = moment(subscriptions[userId].expiry);
    const now = moment();

    if (expiryDate.isBefore(now)) {
        return { valid: false, reason: 'Expired' };
    }

    return { valid: true, expiryDate: expiryDate };
}
// --- Subscription Check Logic --- END ---

let handler = async (m, { conn, args, command, usedPrefix }) => {
    let userId = m.sender;

    // --- Subscription/Owner Check ---
    const subscriptionStatus = hasValidSubscription(userId);
    const isOwner = subscriptionStatus.isOwner || false;

    if (!subscriptionStatus.valid && !isOwner) { // Must be owner or have valid subscription
        if (subscriptionStatus.reason === 'Expired') {
            return m.reply("*╔═════ 🚫 انتهى الاشتراك ═════╗*\n*║* عذراً، اشتراكك في خدمة البث قد انتهى.\n*║* يرجى تجديد اشتراكك للمتابعة.\n*╚════════════════════════╝*");
        }
        return m.reply("*╔═════ 🔒 صلاحية مطلوبة ═════╗*\n*║* ليس لديك الصلاحية لاستخدام هذا الأمر.\n*║* يتطلب اشتراكاً نشطاً أو أن تكون المالك.\n*╚════════════════════════╝*");
    }
    // --- End Subscription/Owner Check ---

    // 1. Validate arguments
    if (args.length < 1) {
        return m.reply(`*╔═════ ⚠️ تحذير ═════╗*
*║* يرجى تحديد معرف البث (Stream ID) 
*║* الذي تريد إيقافه.
*║* 
*║* *مثال:* ${usedPrefix + command} abc123de
*╚═════════════════╝*`);
    }

    let streamIdToStop = args[0];
    let chatId = m.chat; // Keep chatId for replying

    // 2. Check if the stream exists
    if (!global.runningFbStreams || !global.runningFbStreams[streamIdToStop]) {
        return m.reply(`*╔═════ ❓ خطأ ═════╗*
*║* لم يتم العثور على بث مباشر نشط 
*║* بالمعرف: *${streamIdToStop}*
*║* 
*║* تأكد من كتابة المعرف بشكل صحيح أو استخدم *.بثوثي*.
*╚════════════════╝*`);
    }

    const streamInfo = global.runningFbStreams[streamIdToStop];
    const ffmpegProcess = streamInfo.process;

    // --- Permission Check: Owner or Stream Starter ---
    if (!isOwner && streamInfo.startedBy !== userId) {
        return m.reply(`*╔═════ 🚫 ممنوع ═════╗*
*║* عذراً، لا يمكنك إيقاف هذا البث.
*║* يمكنك فقط إيقاف البثوث التي بدأتها بنفسك.
*║* 
*║* هذا البث بدأ بواسطة مستخدم آخر.
*╚════════════════╝*`);
    }
    // --- End Permission Check ---

    // Proceed with stopping the stream
    try {
        // 3. Set a flag to indicate intentional stopping
        streamInfo.stopping = true;

        // 4. Attempt to kill the process gracefully
        ffmpegProcess.kill("SIGTERM"); // Send SIGTERM first
        console.log(`Attempting to gracefully stop FFmpeg process [${streamIdToStop}] via SIGTERM by user ${userId}.`);

        // Send an initial confirmation that the stop command was received
        m.reply(`*╔═════ ⏳ جاري الإيقاف ═════╗*
*║* تم استلام طلب إيقاف البث بالمعرف:
*║* 
*║* *${streamIdToStop}*
*║* 
*║* المصدر الذي كان يبث:
*║* ${streamInfo.sourceUrl || "غير محدد"}
*║* 
*║* يرجى الانتظار قليلاً لتأكيد الإيقاف النهائي...
*╚══════════════════════╝*`);

        // Set a timeout to forcefully kill if it doesn't exit gracefully
        setTimeout(() => {
            // Check if the stream still exists and wasn't killed/closed yet
            if (global.runningFbStreams && global.runningFbStreams[streamIdToStop] && !ffmpegProcess.killed) {
                console.warn(`FFmpeg process [${streamIdToStop}] did not exit gracefully after SIGTERM, sending SIGKILL.`);
                ffmpegProcess.kill("SIGKILL"); // Force kill
            }
        }, 5000); // Wait 5 seconds before force killing

        // Note: Final confirmation and cleanup are handled by the 'close' event listener
        // in fblive_enhanced_v2.js, triggered by the process exiting.

    } catch (error) {
        console.error(`Error stopping FFmpeg process [${streamIdToStop}]: ${error}`);
        m.reply(`*╔═════ ❌ خطأ فادح ═════╗*
*║* حدث خطأ غير متوقع أثناء محاولة 
*║* إيقاف البث [${streamIdToStop}]:
*║* 
*║* ${error.message}
*║* 
*║* قد تحتاج للتحقق من حالة العملية يدوياً.
*╚════════════════════╝*`);
        // Clean up the entry defensively if an error occurred during the kill attempt
        if (global.runningFbStreams && global.runningFbStreams[streamIdToStop]) {
            delete global.runningFbStreams[streamIdToStop];
            console.log(`Cleaned up stream info for [${streamIdToStop}] due to error during stop attempt.`);
        }
    }
};

handler.help = ["fboff <stream_id>"];
handler.tags = ["streaming"]; // Changed tag to general streaming
handler.command = ["fboff", "off", "ايقاف"];
// handler.owner = false; // Removed owner-only restriction, handled inside

export default handler;

