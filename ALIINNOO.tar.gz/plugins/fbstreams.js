import moment from 'moment-timezone';

let handler = async (m, { conn, command }) => {
    // --- Owner Check (Ensures only owners can run this) ---
    const ownerJids = (global.owner || []).map(v => String(v).replace(/[^0-9]/g, '') + '@s.whatsapp.net');
    if (!ownerJids.includes(m.sender)) {
        return m.reply('*╔═════ 🔒 وصول مقيد ═════╗*\n*║* عذراً، هذا الأمر مخصص للمالك فقط.\n*║* لعرض بثوثك الخاصة، استخدم الأمر *.بثوثي*\n*╚══════════════════════╝*');
    }
    // --- End Owner Check ---

    // Access the global stream store
    const streams = global.runningFbStreams || {};
    const streamIds = Object.keys(streams);

    if (streamIds.length === 0) {
        return m.reply("✨ *لا توجد أي عمليات بث مباشر نشطة حاليًا على النظام.* ✨");
    }

    let replyText = `*╔═════ 📡 قائمة جميع البثوث النشطة (${streamIds.length}) ═════╗*
*║* (خاص بالمالك)
*
*`;

    let count = 1;
    for (const streamId of streamIds) {
        const streamInfo = streams[streamId];
        const startTime = streamInfo.startTime || Date.now(); // Fallback
        const duration = moment.duration(Date.now() - startTime);
        const durationFormatted = `${Math.floor(duration.asHours())} س ${duration.minutes()} د ${duration.seconds()} ث`;
        const startedByJid = streamInfo.startedBy || 'غير معروف';
        const startedByUser = startedByJid.split('@')[0];

        replyText += `*║═══ STREAM ${count} (${streamId}) ═══*
`;
        replyText += `*║* 🆔 *المعرف:* 
*║*    └ ${streamId}
`;
        replyText += `*║* 🔗 *المصدر:* 
*║*    └ ${streamInfo.sourceUrl || 'غير محدد'}
`;
        replyText += `*║* ⏳ *المدة:* 
*║*    └ ${durationFormatted}
`;
        replyText += `*║* 👤 *بدأ بواسطة:* 
*║*    └ @${startedByUser}
`;
        replyText += `*║* 💬 *بدأ من دردشة:* 
*║*    └ ${streamInfo.chatId || 'غير محدد'}
`;
        replyText += `*║* 🔄 *محاولات إعادة التشغيل:* ${streamInfo.retries || 0}
`;
        replyText += `*║------------------------------------*
`;
        count++;
    }

    replyText += `*╚══════════════════════════════╝*`;

    // Mention the users who started the streams
    const mentionedUsers = streamIds.map(id => streams[id]?.startedBy).filter(Boolean);
    conn.reply(m.chat, replyText.trim(), m, { mentions: [...new Set(mentionedUsers), m.sender] }); // Mention unique starters and command issuer

};

handler.help = ["streams", "البثوث"]; // Updated help
handler.tags = ["owner", "streaming"];
handler.command = ["streams", "قائمة_البث", "البثوث"]; // Added the new alias
handler.owner = true; // Keep owner check for safety

export default handler;

