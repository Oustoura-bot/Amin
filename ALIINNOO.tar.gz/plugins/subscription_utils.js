import fs from 'fs';
import moment from 'moment-timezone';

const SUBS_FILE = './subscriptions.json'; // Path to the subscription file
const TRIAL_DURATION_DAYS = 10; // Duration for the automatic trial

/**
 * Reads subscription data from the JSON file.
 * @returns {object} The subscription data object.
 */
function readSubscriptions() {
    try {
        if (fs.existsSync(SUBS_FILE)) {
            const data = fs.readFileSync(SUBS_FILE, 'utf8');
            if (!data) return {};
            return JSON.parse(data);
        } else {
            return {};
        }
    } catch (error) {
        console.error("Error reading subscriptions file:", error);
        return {};
    }
}

/**
 * Writes subscription data to the JSON file.
 * @param {object} subscriptions The subscription data object to write.
 * @returns {boolean} True if successful, false otherwise.
 */
function writeSubscriptions(subscriptions) {
    try {
        fs.writeFileSync(SUBS_FILE, JSON.stringify(subscriptions, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error("Error writing subscriptions file:", error);
        return false;
    }
}

/**
 * Checks if a user has a valid subscription or grants a trial if they are new.
 * Sends notifications upon granting a trial.
 * @param {string} userId The user's JID.
 * @param {object} conn The connection object (for sending messages).
 * @param {object} m The message object (for context like chat ID).
 * @returns {Promise<object>} A promise resolving to an object indicating subscription status: { valid: boolean, isOwner?: boolean, isTrial?: boolean, trialJustGranted?: boolean, expiryDate?: moment.Moment, reason?: string }.
 */
async function checkAndGrantSubscription(userId, conn, m) {
    const ownerJids = (global.owner || []).map(v => String(v).replace(/[^0-9]/g, '') + '@s.whatsapp.net');
    if (ownerJids.includes(userId)) {
        return { valid: true, isOwner: true };
    }

    const subscriptions = readSubscriptions();

    if (!subscriptions[userId]) {
        // --- New User: Grant Trial --- 
        console.log(`User ${userId} not found. Granting ${TRIAL_DURATION_DAYS}-day trial.`);
        const now = moment();
        const expiryDate = now.clone().add(TRIAL_DURATION_DAYS, 'days');
        
        subscriptions[userId] = {
            expiry: expiryDate.toISOString(),
            addedBy: 'AutoTrial',
            addedOn: now.toISOString()
        };

        if (writeSubscriptions(subscriptions)) {
            console.log(`Successfully granted ${TRIAL_DURATION_DAYS}-day trial to ${userId}. Expires: ${expiryDate.format()}`);
            
            // --- Send Notifications --- 
            try {
                // 1. Notify User
                const userMsg = `*╔═════ 🎉 عرض محدود! ═════╗*
*║* مبروك! لقد حصلت على اشتراك تجريبي مجاني!
*║* 
*║* 🎁 *المدة:* ${TRIAL_DURATION_DAYS} أيام
*║* 📅 *تاريخ الانتهاء:* ${expiryDate.format('YYYY-MM-DD')}
*║* 
*║* استمتع بتجربة البوت الكاملة!
*╚══════════════════════╝*`;
                await conn.reply(m.chat, userMsg, m); // Send in the user's chat

                // 2. Notify Owner(s)
                const ownerMsg = `*╔═════ ℹ️ إشعار مالك ═════╗*
*║* تم منح اشتراك تجريبي تلقائي:
*║* 
*║* 👤 *المستخدم:* @${userId.split('@')[0]}
*║* ⏳ *المدة:* ${TRIAL_DURATION_DAYS} أيام
*║* 📅 *تاريخ الانتهاء:* ${expiryDate.format('YYYY-MM-DD')}
*╚══════════════════════╝*`;
                for (const ownerJid of ownerJids) {
                    await conn.sendMessage(ownerJid, { text: ownerMsg, mentions: [userId] });
                }
            } catch (notifyError) {
                console.error(`Error sending trial notifications for ${userId}:`, notifyError);
                // Continue even if notifications fail, the trial was granted.
            }
            // --- End Notifications ---

            return { valid: true, isTrial: true, trialJustGranted: true, expiryDate: expiryDate };
        } else {
            console.error(`Failed to write subscriptions file after granting trial to ${userId}.`);
            return { valid: false, reason: 'Trial grant failed (write error)' };
        }
        // --- End Trial Grant ---

    } else {
        // --- Existing User: Check Expiry --- 
        if (!subscriptions[userId].expiry) {
            console.warn(`User ${userId} found but has no expiry date.`);
            return { valid: false, reason: 'Subscription data invalid (no expiry)' };
        }

        const expiryDate = moment(subscriptions[userId].expiry);
        const now = moment();

        if (expiryDate.isBefore(now)) {
            console.log(`Subscription for ${userId} expired on ${expiryDate.format()}.`);
            return { valid: false, reason: 'Expired' };
        }

        // Valid subscription (not a trial being granted now)
        return { valid: true, expiryDate: expiryDate };
        // --- End Expiry Check ---
    }
}

export { readSubscriptions, writeSubscriptions, checkAndGrantSubscription };

