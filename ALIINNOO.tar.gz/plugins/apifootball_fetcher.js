// apifootball_fetcher.js - Module to fetch match data from API-Football

import fetch from 'node-fetch';

// --- Configuration ---
const API_FOOTBALL_URL = 'https://v3.football.api-sports.io';
const API_KEY = 'bac69b62b8334ef2a42983a2fdba458d'; // User provided API key

// --- Main Fetching Function ---
/**
 * Fetches fixtures for a specific date from API-Football.
 * @param {string} date - The date in YYYY-MM-DD format.
 * @returns {Promise<object[]>} - A promise that resolves to an array of fixture objects.
 */
async function fetchApiFootballFixtures(date) {
    const endpoint = `/fixtures?date=${date}`;
    const url = `${API_FOOTBALL_URL}${endpoint}`;

    console.log(`Fetching data from API-Football: ${url}`);

    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'x-apisports-key': API_KEY,
                // Add other headers if needed, but API-Football docs suggest only the key is required for API-Sports URL
            }
        });

        const responseData = await response.json();

        // Log rate limit headers for debugging
        console.log(`API-Football Rate Limit: ${response.headers.get('x-ratelimit-requests-limit')}`);
        console.log(`API-Football Remaining: ${response.headers.get('x-ratelimit-requests-remaining')}`);

        if (!response.ok) {
            console.error('API-Football Error Response:', responseData);
            throw new Error(`فشل طلب API-Football: ${response.status} ${response.statusText} - ${JSON.stringify(responseData.errors || responseData.message || '')}`);
        }

        if (responseData.errors && Object.keys(responseData.errors).length > 0) {
            console.error('API-Football Logical Errors:', responseData.errors);
            // Try to format the error message
            let errorMsg = Object.entries(responseData.errors)
                               .map(([key, value]) => `${key}: ${value}`)
                               .join(', ');
            throw new Error(`خطأ من API-Football: ${errorMsg}`);
        }

        if (!responseData.response || responseData.results === 0) {
            console.log(`No fixtures found for date: ${date}`);
            return []; // Return empty array if no results
        }

        console.log(`Fetched ${responseData.results} fixtures for ${date}.`);
        return responseData.response; // Return the array of fixtures

    } catch (error) {
        console.error('❌ Error during API-Football fetch:', error);
        // Re-throw the error to be handled by the caller
        throw new Error(`فشل الاتصال أو معالجة الاستجابة من API-Football: ${error.message}`);
    }
}

export { fetchApiFootballFixtures };

// Example usage (for testing):
/*
const today = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD
fetchApiFootballFixtures(today)
    .then(data => {
        console.log('--- Today (API-Football) ---');
        console.log(JSON.stringify(data.slice(0, 2), null, 2)); // Log first 2 fixtures
    })
    .catch(err => console.error(err));
*/

