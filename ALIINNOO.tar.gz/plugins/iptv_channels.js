// بسم الله الرحمن الرحيم ✨✨✨

// استيراد الوحدات المطلوبة
import fetch from 'node-fetch';
import axios from 'axios'; // axios is already a dependency

// قائمة الدول مع الإيموجي (تبقى كما هي)
const countries = {
    // ... (قائمة الدول كما هي)
    'MA': '🇲🇦 المغرب', 'DZ': '🇩🇿 الجزائر', 'TN': '🇹🇳 تونس', 'EG': '🇪🇬 مصر', 'LY': '🇱🇾 ليبيا',
    'SD': '🇸🇩 السودان', 'NG': '🇳🇬 نيجيريا', 'KE': '🇰🇪 كينيا', 'ZA': '🇿🇦 جنوب أفريقيا', 'ET': '🇪🇹 إثيوبيا',
    'GH': '🇬🇭 غانا', 'SN': '🇸🇳 السنغال', 'CI': '🇨🇮 ساحل العاج', 'CM': '🇨🇲 الكاميرون', 'AO': '🇦🇴 أنغولا',
    'MZ': '🇲🇿 موزمبيق', 'UG': '🇺🇬 أوغندا', 'TZ': '🇹🇿 تنزانيا', 'RW': '🇷🇼 رواندا', 'ML': '🇲🇱 مالي',
    'SA': '🇸🇦 السعودية', 'AE': '🇦🇪 الإمارات', 'QA': '🇶🇦 قطر', 'KW': '🇰🇼 الكويت',
    'BH': '🇧🇭 البحرين', 'OM': '🇴🇲 عمان', 'JO': '🇯🇴 الأردن', 'LB': '🇱🇧 لبنان', 'SY': '🇸🇾 سوريا',
    'IQ': '🇮🇶 العراق', 'IR': '🇮🇷 إيران', 'IL': '🇮🇱 إسرائيل', 'PS': '🇵🇸 فلسطين', 'YE': '🇾🇪 اليمن',
    'FR': '🇫🇷 فرنسا', 'GB': '🇬🇧 المملكة المتحدة', 'DE': '🇩🇪 ألمانيا', 'IT': '🇮🇹 إيطاليا', 'ES': '🇪🇸 إسبانيا',
    'PT': '🇵🇹 البرتغال', 'NL': '🇳🇱 هولندا', 'BE': '🇧🇪 بلجيكا', 'CH': '🇨🇭 سويسرا', 'AT': '🇦🇹 النمسا',
    'GR': '🇬🇷 اليونان', 'TR': '🇹🇷 تركيا', 'RU': '🇷🇺 روسيا', 'UA': '🇺🇦 أوكرانيا', 'PL': '🇵🇱 بولندا',
    'SE': '🇸🇪 السويد', 'NO': '🇳🇴 النرويج', 'DK': '🇩🇰 الدنمارك', 'FI': '🇫🇮 فنلندا', 'IE': '🇮🇪 أيرلندا',
    'CZ': '🇨🇿 التشيك', 'HU': '🇭🇺 المجر', 'RO': '🇷🇴 رومانيا', 'BG': '🇧🇬 بلغاريا', 'HR': '🇭🇷 كرواتيا',
    'RS': '🇷🇸 صربيا', 'SK': '🇸🇰 سلوفاكيا', 'SI': '🇸🇮 سلوفينيا', 'AL': '🇦🇱 ألبانيا', 'MK': '🇲🇰 مقدونيا الشمالية',
    'MT': '🇲🇹 مالطا', 'CY': '🇨🇾 قبرص',
    'US': '🇺🇸 الولايات المتحدة', 'CA': '🇨🇦 كندا', 'MX': '🇲🇽 المكسيك', 'BR': '🇧🇷 البرازيل', 'AR': '🇦🇷 الأرجنتين',
    'CO': '🇨🇴 كولومبيا', 'CL': '🇨🇱 تشيلي', 'PE': '🇵🇪 بيرو', 'VE': '🇻🇪 فنزويلا', 'CU': '🇨🇺 كوبا',
    'DO': '🇩🇴 الدومينيكان', 'EC': '🇪🇨 الإكوادور', 'GT': '🇬🇹 غواتيمالا', 'PA': '🇵🇦 بنما',
    'CR': '🇨🇷 كوستاريكا', 'UY': '🇺🇾 الأوروغواي', 'PR': '🇵🇷 بورتوريكو', 'JM': '🇯🇲 جامايكا',
    'CN': '🇨🇳 الصين', 'JP': '🇯🇵 اليابان', 'KR': '🇰🇷 كوريا الجنوبية', 'IN': '🇮🇳 الهند', 'PK': '🇵🇰 باكستان',
    'BD': '🇧🇩 بنغلاديش', 'ID': '🇮🇩 إندونيسيا', 'MY': '🇲🇾 ماليزيا', 'SG': '🇸🇬 سنغافورة', 'TH': '🇹🇭 تايلاند',
    'VN': '🇻🇳 فيتنام', 'PH': '🇵🇭 الفلبين', 'HK': '🇭🇰 هونغ كونغ', 'TW': '🇹🇼 تايوان', 'KZ': '🇰🇿 كازاخستان',
    'UZ': '🇺🇿 أوزبكستان', 'LK': '🇱🇰 سريلانكا', 'NP': '🇳🇵 نيبال', 'MM': '🇲🇲 ميانمار', 'KH': '🇰🇭 كمبوديا',
    'AU': '🇦🇺 أستراليا', 'NZ': '🇳🇿 نيوزيلندا', 'FJ': '🇫🇯 فيجي', 'PG': '🇵🇬 بابوا غينيا الجديدة', 'SB': '🇸🇧 جزر سليمان'
};

// قائمة الفئات مع الإيموجي (تبقى كما هي)
const categories = {
    'animation': '🎬 رسوم متحركة', 
    'auto': '🚗 سيارات',
    'business': '💼 أعمال',
    'classic': '🎞️ كلاسيك',
    'comedy': '😂 كوميديا',
    'cooking': '🍳 طبخ',
    'culture': '🎭 ثقافة',
    'documentary': '🌍 وثائقي',
    'education': '🎓 تعليم',
    'entertainment': '🎉 ترفيه',
    'family': '👨‍👩‍👧‍👦 عائلة',
    'general': '🌐 عام',
    'kids': '🧸 أطفال',
    'legislative': '🏛️ تشريعي',
    'lifestyle': '💅 أسلوب حياة',
    'movies': '🍿 أفلام',
    'music': '🎵 موسيقى',
    'news': '📰 أخبار',
    'outdoor': '🌳 خارجي',
    'relax': '🧘 استرخاء',
    'religious': '🙏 ديني',
    'science': '🔬 علوم',
    'series': '📺 مسلسلات',
    'shop': '🛒 تسوق',
    'sports': '⚽ رياضة',
    'travel': '✈️ سفر',
    'weather': '☀️ طقس'
};

// Helper function for delay (تبقى كما هي)
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// Function to fetch and parse M3U file (تبقى كما هي مع تعديل رسائل الخطأ)
async function fetchAndParseM3U(url) {
    console.log(`[IPTV DEBUG] Attempting to fetch channels from: ${url}`);
    try {
        const response = await axios.get(url, { 
            timeout: 30000, 
            headers: { 'User-Agent': 'Mozilla/5.0' } 
        }); 
        console.log(`[IPTV DEBUG] Successfully fetched from ${url}. Status: ${response.status}`);
        const m3uContent = response.data;
        
        if (!m3uContent || typeof m3uContent !== 'string') {
            console.error('[IPTV DEBUG] M3U content is empty or not a string.');
            return [];
        }

        const lines = m3uContent.split('\n');
        const channels = [];
        let currentChannel = {};

        for (const line of lines) {
            const trimmedLine = line.trim();
            if (trimmedLine.startsWith('#EXTINF:')) {
                currentChannel = {}; 
                const titleMatch = trimmedLine.match(/,(.+)$/);
                currentChannel.title = titleMatch ? titleMatch[1].trim() : 'قناة غير معروفة';
                
                const tvgNameMatch = trimmedLine.match(/tvg-name="([^\"]+)"/);
                if (tvgNameMatch && tvgNameMatch[1]) {
                    currentChannel.title = tvgNameMatch[1].trim();
                }
                
            } else if (trimmedLine && !trimmedLine.startsWith('#') && trimmedLine.toLowerCase().includes('.m3u8')) {
                 if (trimmedLine.startsWith('http://') || trimmedLine.startsWith('https://')) {
                    currentChannel.url = trimmedLine;
                    if (currentChannel.title && currentChannel.url) {
                        if (!channels.some(ch => ch.url === currentChannel.url)) {
                           channels.push({ ...currentChannel });
                        }
                    }
                 } else {
                     console.log(`[IPTV DEBUG] Skipping non-URL line: ${trimmedLine}`);
                 }
                 currentChannel = {};
            }
        }
        
        console.log(`[IPTV DEBUG] Parsed ${channels.length} M3U8 channels from ${url}`);
        return channels;
    } catch (error) {
        console.error(`[IPTV DEBUG] Error fetching or parsing M3U from ${url}:`, error);
        let errorMessage = '';
        if (axios.isAxiosError(error)) {
            if (error.response) {
                 console.error(`[IPTV DEBUG] Server responded with status: ${error.response.status}`);
                 if (error.response.status === 404) {
                     errorMessage = `*المصدر غير موجود (404)*: ${url}`;
                 } else {
                     errorMessage = `*خطأ من الخادم (${error.response.status})*: ${url}`;
                 }
            } else if (error.request) {
                 console.error('[IPTV DEBUG] No response received from server.');
                 errorMessage = `*لا يوجد استجابة من الخادم*: ${url}`;
            } else {
                 console.error('[IPTV DEBUG] Error setting up the request:', error.message);
                 errorMessage = `*خطأ في إعداد الطلب*: ${error.message}`;
            }
            if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
                console.error(`[IPTV DEBUG] Timeout fetching ${url}`);
                errorMessage = `*انتهت مهلة جلب القائمة (30 ثانية)*: ${url}`;
            }
        } else {
             console.error('[IPTV DEBUG] Non-Axios error:', error);
             errorMessage = `*خطأ غير متوقع*: ${error.message}`;
        }
        // Throw a formatted error message (Strong & Luxurious Design)
        throw new Error(`
*═════ [ 💥 خطأ فادح 💥 ] ═════*

*🚫 فشل جلب القنوات.*
*السبب:* ${errorMessage || 'خطأ غير معروف.'}
`); 
    }
}

// Function to find country code by name (تبقى كما هي)
function findCountryCode(name) {
    const searchTerm = name.toLowerCase().trim();
    for (const [code, countryName] of Object.entries(countries)) {
        if (code.toLowerCase() === searchTerm || countryName.toLowerCase().includes(searchTerm)) {
            return code;
        }
    }
    return null;
}

// Function to find category code by name (تبقى كما هي)
function findCategoryCode(name) {
    const searchTerm = name.toLowerCase().trim();
    for (const [code, categoryName] of Object.entries(categories)) {
        if (code.toLowerCase() === searchTerm || categoryName.toLowerCase().includes(searchTerm)) {
            return code;
        }
    }
    return null;
}

// --- المعالج الرئيسي مع تصميم الرسائل القوي والفاخر ---
let handler = async (m, { conn, text, usedPrefix, command, args }) => {
    console.log(`[IPTV DEBUG] Command received: ${usedPrefix + command} ${args.join(' ')}`);
    const CHUNK_SIZE = 10; 
    const MESSAGE_DELAY = 1500; 

    let choice = args[0]?.toLowerCase();
    let selectionText = args.slice(1).join(' ').trim();

    // --- رسالة المساعدة القوية والفاخرة ---
    if (!choice) {
        console.log('[IPTV DEBUG] Displaying strong & luxurious help message.');
        let helpMsg = `
*═════ [ 👑 مستكشف IPTV الملكي 👑 ] ═════*

✨ *أهلاً بك! استكشف عالم البث الرقمي:*

*📌 الأوامر المتاحة:*

*1. عرض قائمة الدول 🌍:*
   *
${usedPrefix + command} country
*
*2. عرض قائمة الفئات 📚:*
   *
${usedPrefix + command} category
*
*3. البحث عن قنوات دولة 🗺️:*
   *
${usedPrefix + command} country <الرمز أو الاسم>
*
   *مثال:* 
${usedPrefix + command} country FR

*4. البحث عن قنوات فئة 🎬:*
   *
${usedPrefix + command} category <الرمز أو الاسم>
*
   *مثال:* 
${usedPrefix + command} category movies

*══════════════════════════════*
   *👑ALINO-BOT-LIVE-STREAMS👑*
        `;
        try {
            await m.reply(helpMsg);
            console.log('[IPTV DEBUG] Strong & luxurious help message sent successfully.');
        } catch (e) {
            console.error('[IPTV DEBUG] Error sending strong & luxurious help message:', e);
            m.reply('حدث خطأ أثناء عرض رسالة المساعدة.');
        }
        return;
    }

    // --- عرض قائمة الدول أو الفئات بتصميم قوي وفاخر ---
    if (choice === 'country' && !selectionText) {
        console.log('[IPTV DEBUG] Displaying strong & luxurious country list.');
        let countryListContent = '';
        const countryEntries = Object.entries(countries);
        countryEntries.forEach(([code, name], index) => {
            countryListContent += `*${code}:* ${name}${index % 2 === 1 ? '\n' : '   |   '}`;
        });
        if (countryEntries.length % 2 !== 0) {
             countryListContent = countryListContent.replace(/\s*\|\s*$/, '');
        }

        let countryListMsg = `
*═════ [ 🌍 قائمة الدول المتاحة 🌍 ] ═════*

*الرمز* : *الاسم*
─────────────────────────
${countryListContent.trim()}
─────────────────────────
*✨ للبحث، استخدم:* 
${usedPrefix + command} country <الرمز أو الاسم>
        `;
        try {
            await m.reply(countryListMsg.trim());
            console.log('[IPTV DEBUG] Strong & luxurious country list sent successfully.');
        } catch (e) {
            console.error('[IPTV DEBUG] Error sending strong & luxurious country list:', e);
            m.reply('حدث خطأ أثناء عرض قائمة الدول.');
        }
        return;

    } else if (choice === 'category' && !selectionText) {
        console.log('[IPTV DEBUG] Displaying strong & luxurious category list.');
        let categoryListContent = '';
        const categoryEntries = Object.entries(categories);
        categoryEntries.forEach(([code, name], index) => {
            categoryListContent += `*${code}:* ${name}${index % 2 === 1 ? '\n' : '   |   '}`;
        });
        if (categoryEntries.length % 2 !== 0) {
             categoryListContent = categoryListContent.replace(/\s*\|\s*$/, '');
        }

        let categoryListMsg = `
*═════ [ 📚 قائمة الفئات المتاحة 📚 ] ═════*

*الرمز* : *الاسم*
─────────────────────────
${categoryListContent.trim()}
─────────────────────────
*✨ للبحث، استخدم:* 
${usedPrefix + command} category <الرمز أو الاسم>
        `;
        try {
            await m.reply(categoryListMsg.trim());
            console.log('[IPTV DEBUG] Strong & luxurious category list sent successfully.');
        } catch (e) {
            console.error('[IPTV DEBUG] Error sending strong & luxurious category list:', e);
            m.reply('حدث خطأ أثناء عرض قائمة الفئات.');
        }
        return;
    }

    // --- جلب وعرض القنوات مع رسائل قوية وفاخرة ---
    console.log(`[IPTV DEBUG] Proceeding to fetch channels. Choice: ${choice}, Selection Text: ${selectionText}`);
    let channels = [];
    let searchParamName = ''; 
    let searchParamCode = ''; 
    let url = '';
    let searchTypeDisplay = ''; 

    // رسالة البحث القوية والفاخرة
    const searchingMsgTemplate = (type, name) => `
*⏳ جاري البحث ⚡️*
*فضلاً انتظر قليلاً بينما نستكشف قنوات ${type}: ${name} ...*
`;

    if (choice === 'country' && selectionText) {
        searchParamCode = findCountryCode(selectionText);
        if (searchParamCode && countries[searchParamCode]) {
            searchParamName = countries[searchParamCode];
            searchTypeDisplay = 'الدولة';
            url = `https://iptv-org.github.io/iptv/countries/${searchParamCode.toLowerCase()}.m3u`;
            console.log(`[IPTV DEBUG] Found country code ${searchParamCode}. Set URL for country ${searchParamName}: ${url}`);
            await m.reply(searchingMsgTemplate(searchTypeDisplay, searchParamName));
        } else {
            console.log(`[IPTV DEBUG] Invalid or unknown country selection: ${selectionText}`);
            return m.reply(`
*═════ [ 🚫 خطأ في الإدخال 🚫 ] ═════*

*الدولة غير موجودة:* \"${selectionText}\".
*استخدم:* 
${usedPrefix + command} country
 *لعرض القائمة.*
`);
        }
    } else if (choice === 'category' && selectionText) {
        searchParamCode = findCategoryCode(selectionText);
        if (searchParamCode && categories[searchParamCode]) {
            searchParamName = categories[searchParamCode];
            searchTypeDisplay = 'الفئة';
            url = `https://iptv-org.github.io/iptv/categories/${searchParamCode}.m3u`;
             console.log(`[IPTV DEBUG] Found category code ${searchParamCode}. Set URL for category ${searchParamName}: ${url}`);
            await m.reply(searchingMsgTemplate(searchTypeDisplay, searchParamName));
        } else {
            console.log(`[IPTV DEBUG] Invalid or unknown category selection: ${selectionText}`);
            return m.reply(`
*═════ [ 🚫 خطأ في الإدخال 🚫 ] ═════*

*الفئة غير موجودة:* \"${selectionText}\".
*استخدم:* 
${usedPrefix + command} category
 *لعرض القائمة.*
`);
        }
    } else {
        console.log(`[IPTV DEBUG] Invalid command structure or choice. Choice: ${choice}, Selection: ${selectionText}`);
        return m.reply(`
*═════ [ ❓ استخدام غير صحيح ❓ ] ═════*

*يرجى مراجعة طريقة استخدام الأمر.*
*استخدم:* 
${usedPrefix + command}
 *لعرض المساعدة.*
`);
    }

    // --- جلب القنوات ---
    try {
        channels = await fetchAndParseM3U(url);
        if (channels === null) { 
             console.log(`[IPTV DEBUG] fetchAndParseM3U returned null for ${url}`);
             return m.reply(`
*═════ [ ⚠️ تنبيه ⚠️ ] ═════*

*القائمة غير متوفرة حالياً لـ ${searchTypeDisplay}: ${searchParamName}.*
`);
        }
    } catch (error) {
        console.error(`[IPTV DEBUG] Error caught in main handler after fetch/parse attempt for ${searchParamName}:`, error);
        return m.reply(error.message || `*⚠️ حدث خطأ غير متوقع أثناء البحث عن قنوات ${searchParamName}.*`);
    }

    // --- رسالة عدم وجود نتائج ---
    if (!channels || channels.length === 0) {
        console.log(`[IPTV DEBUG] No valid M3U8 channels found for ${searchParamName} after parsing.`);
        return m.reply(`
*═════ [ 💨 لا توجد نتائج 💨 ] ═════*

*لم يتم العثور على قنوات M3U8 صالحة حالياً لـ ${searchTypeDisplay}: ${searchParamName}.*
`);
    }

    const totalChannels = channels.length;
    const numChunks = Math.ceil(totalChannels / CHUNK_SIZE);
    console.log(`[IPTV DEBUG] Found ${totalChannels} channels for ${searchParamName}. Preparing to send in ${numChunks} chunks.`);

    // --- رسالة العثور على النتائج ---
    let resultsFoundMsg = `
*═════ [ 🎉 نتائج البحث: ${searchTypeDisplay} ${searchParamName} 🎉 ] ═════*

*✨ تم العثور على ${totalChannels} قناة! ✨*
*سيتم الإرسال في ${numChunks} جزء/أجزاء.*
`;
    await m.reply(resultsFoundMsg);
    await delay(MESSAGE_DELAY);

    // --- إرسال النتائج في أجزاء ---
    for (let i = 0; i < totalChannels; i += CHUNK_SIZE) {
        const chunk = channels.slice(i, i + CHUNK_SIZE);
        const chunkNumber = Math.floor(i / CHUNK_SIZE) + 1;
        let chunkContent = '';
        chunk.forEach((channel, index) => {
            // تنسيق قوي وفاخر لكل قناة
            chunkContent += `*🌟 ${channel.title.replace(/\[.*?\]/g, '').trim()}*
   🔗 
${channel.url}

`;
        });

        let chunkMsg = `
*--- [ 📺 قنوات ${searchTypeDisplay}: ${searchParamName} | الجزء ${chunkNumber}/${numChunks} 📺 ] ---*

${chunkContent.trim()}
`;

        try {
            await m.reply(chunkMsg.trim());
            console.log(`[IPTV DEBUG] Sent chunk ${chunkNumber}/${numChunks} for ${searchParamName}`);
        } catch (e) {
            console.error(`[IPTV DEBUG] Error sending chunk ${chunkNumber}:`, e);
            await m.reply(`
*═════ [ 💥 خطأ في الإرسال 💥 ] ═════*

*حدث خطأ أثناء إرسال الجزء ${chunkNumber}.*
`);
        }
        if (i + CHUNK_SIZE < totalChannels) {
            await delay(MESSAGE_DELAY);
        }
    }
    console.log(`[IPTV DEBUG] Finished sending all chunks for ${searchParamName}.`);
};

// --- البيانات الوصفية لـ Silana-Lite (تبقى كما هي) ---
handler.command = /^(iptv|قنوات)$/i;
handler.help = ['iptv'];
handler.tags = ['tools', 'search', 'iptv'];
handler.limit = true;

export default handler;

