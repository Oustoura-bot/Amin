import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

// مسار قاعدة البيانات
const DB_PATH = './iptv_channels_db.json';

// التأكد من وجود قاعدة البيانات
if (!fs.existsSync(DB_PATH)) {
  console.error('قاعدة البيانات غير موجودة!');
  process.exit(1);
}

// قراءة قاعدة البيانات
let db;
try {
  const data = fs.readFileSync(DB_PATH, 'utf8');
  db = JSON.parse(data);
} catch (error) {
  console.error('خطأ في قراءة قاعدة البيانات:', error);
  process.exit(1);
}

// تحديث قاعدة البيانات
const updateDatabase = () => {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf8');
  } catch (error) {
    console.error('خطأ في تحديث قاعدة البيانات:', error);
  }
};

// استخراج القنوات من ملف M3U
const parseM3U = async (url) => {
  try {
    const response = await fetch(url);
    const text = await response.text();
    
    const lines = text.split('\n');
    const channels = [];
    
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].startsWith('#EXTINF:')) {
        const info = lines[i];
        const streamUrl = lines[i + 1];
        
        if (streamUrl && !streamUrl.startsWith('#')) {
          // استخراج معلومات القناة
          const titleMatch = info.match(/tvg-id="([^"]*)".*tvg-logo="([^"]*)".*group-title="([^"]*)",(.+)/);
          
          if (titleMatch) {
            const [, id, logo, group, title] = titleMatch;
            
            channels.push({
              id: id || `channel_${channels.length}`,
              name: title.trim(),
              logo: logo || '',
              category: group.toLowerCase() || 'general',
              url: streamUrl.trim()
            });
          }
        }
      }
    }
    
    return channels;
  } catch (error) {
    console.error('خطأ في استخراج القنوات:', error);
    return [];
  }
};

// تحديث التخزين المؤقت للقنوات
const updateChannelsCache = async (categoryId) => {
  const category = db.categories.find(cat => cat.id === categoryId);
  
  if (!category) {
    return [];
  }
  
  try {
    const channels = await parseM3U(category.playlist_url);
    
    // تحديث التخزين المؤقت
    db.cache.channels[categoryId] = {
      lastUpdate: new Date().toISOString(),
      data: channels
    };
    
    updateDatabase();
    
    return channels;
  } catch (error) {
    console.error(`خطأ في تحديث التخزين المؤقت للفئة ${categoryId}:`, error);
    return [];
  }
};

// الحصول على قنوات فئة معينة
const getCategoryChannels = async (categoryId) => {
  // التحقق من وجود تخزين مؤقت حديث
  const cache = db.cache.channels[categoryId];
  const now = new Date();
  
  if (cache && cache.lastUpdate) {
    const lastUpdate = new Date(cache.lastUpdate);
    const hoursSinceUpdate = (now - lastUpdate) / (1000 * 60 * 60);
    
    // إذا كان التحديث الأخير قبل أقل من 24 ساعة، استخدم التخزين المؤقت
    if (hoursSinceUpdate < 24) {
      return cache.data;
    }
  }
  
  // تحديث التخزين المؤقت
  return await updateChannelsCache(categoryId);
};

// البحث عن قنوات
const searchChannels = async (query) => {
  const results = [];
  
  // البحث في جميع الفئات
  for (const category of db.categories) {
    const channels = await getCategoryChannels(category.id);
    
    const matchingChannels = channels.filter(channel => 
      channel.name.toLowerCase().includes(query.toLowerCase())
    );
    
    results.push(...matchingChannels);
  }
  
  return results;
};

// إنشاء ملف M3U للقنوات
const createM3UPlaylist = (channels, title) => {
  let content = '#EXTM3U\n';
  
  channels.forEach(channel => {
    content += `#EXTINF:-1 tvg-id="${channel.id}" tvg-logo="${channel.logo}" group-title="${channel.category}",${channel.name}\n`;
    content += `${channel.url}\n`;
  });
  
  const fileName = `${title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.m3u`;
  const filePath = path.join('./playlists', fileName);
  
  // التأكد من وجود مجلد playlists
  if (!fs.existsSync('./playlists')) {
    fs.mkdirSync('./playlists', { recursive: true });
  }
  
  fs.writeFileSync(filePath, content, 'utf8');
  
  return filePath;
};

// معالج الأوامر
let handler = async (m, { conn, args, text, command }) => {
  switch (command) {
    case 'قنوات':
    case 'channels':
      // عرض قائمة الفئات
      let categoriesList = db.categories.map(cat => `${cat.icon} *${cat.name}*: .${cat.id}`).join('\n');
      
      m.reply(`*📺 قائمة فئات القنوات:*\n\n${categoriesList}\n\n_اختر فئة بإرسال الأمر المقابل لها_`);
      break;
      
    case 'sports':
    case 'movies':
    case 'news':
    case 'music':
    case 'kids':
    case 'entertainment':
    case 'documentary':
    case 'general':
    case 'arabic':
    case 'رياضة':
    case 'أفلام':
    case 'أخبار':
    case 'موسيقى':
    case 'أطفال':
    case 'ترفيه':
    case 'وثائقي':
    case 'عام':
    case 'عربي':
      // تحويل الأوامر العربية إلى معرفات الفئات
      const categoryMapping = {
        'رياضة': 'sports',
        'أفلام': 'movies',
        'أخبار': 'news',
        'موسيقى': 'music',
        'أطفال': 'kids',
        'ترفيه': 'entertainment',
        'وثائقي': 'documentary',
        'عام': 'general',
        'عربي': 'arabic'
      };
      
      const categoryId = categoryMapping[command] || command;
      const category = db.categories.find(cat => cat.id === categoryId);
      
      if (!category) {
        return m.reply('❌ فئة غير موجودة!');
      }
      
      m.reply(`🔄 جاري تحميل قنوات ${category.name}...`);
      
      try {
        const channels = await getCategoryChannels(categoryId);
        
        if (channels.length === 0) {
          return m.reply(`❌ لم يتم العثور على قنوات في فئة ${category.name}`);
        }
        
        // إنشاء ملف M3U
        const playlistPath = createM3UPlaylist(channels, category.name);
        
        // إرسال الملف
        await conn.sendFile(m.chat, playlistPath, path.basename(playlistPath), `قائمة تشغيل ${category.name} (${channels.length} قناة)`, m);
        
        // إرسال رسالة بالقنوات الأولى
        const topChannels = channels.slice(0, 10);
        let channelsList = topChannels.map((channel, index) => `${index + 1}. *${channel.name}*`).join('\n');
        
        m.reply(`*📺 قنوات ${category.name} (${channels.length} قناة):*\n\n${channelsList}\n\n_تم إرسال ملف M3U كامل يحتوي على جميع القنوات_\n\nلتشغيل القنوات، استخدم تطبيق مشغل IPTV مثل VLC أو IPTV Smarters أو Perfect Player`);
      } catch (error) {
        console.error(error);
        m.reply(`❌ حدث خطأ أثناء تحميل قنوات ${category.name}`);
      }
      break;
      
    case 'بحث':
    case 'search':
      if (!text) {
        return m.reply('⚠️ يرجى إدخال اسم القناة للبحث عنها.\nمثال: .بحث الجزيرة');
      }
      
      m.reply(`🔍 جاري البحث عن "${text}"...`);
      
      try {
        const results = await searchChannels(text);
        
        if (results.length === 0) {
          return m.reply(`❌ لم يتم العثور على نتائج لـ "${text}"`);
        }
        
        // إنشاء ملف M3U
        const playlistPath = createM3UPlaylist(results, `search_${text}`);
        
        // إرسال الملف
        await conn.sendFile(m.chat, playlistPath, path.basename(playlistPath), `نتائج البحث عن "${text}" (${results.length} قناة)`, m);
        
        // إرسال رسالة بالنتائج
        const topResults = results.slice(0, 10);
        let resultsList = topResults.map((channel, index) => `${index + 1}. *${channel.name}* (${db.categories.find(cat => cat.id === channel.category)?.name || channel.category})`).join('\n');
        
        m.reply(`*🔍 نتائج البحث عن "${text}" (${results.length} قناة):*\n\n${resultsList}\n\n_تم إرسال ملف M3U يحتوي على جميع النتائج_`);
      } catch (error) {
        console.error(error);
        m.reply(`❌ حدث خطأ أثناء البحث عن "${text}"`);
      }
      break;
      
    case 'تحديث':
    case 'update':
      // التحقق من صلاحيات المالك
      if (!m.isOwner && !m.fromMe) {
        return m.reply('❌ هذا الأمر متاح فقط للمالك.');
      }
      
      m.reply('🔄 جاري تحديث قاعدة بيانات القنوات...');
      
      try {
        // تحديث جميع الفئات
        for (const category of db.categories) {
          await updateChannelsCache(category.id);
        }
        
        db.cache.last_update = new Date().toISOString();
        updateDatabase();
        
        m.reply('✅ تم تحديث قاعدة بيانات القنوات بنجاح!');
      } catch (error) {
        console.error(error);
        m.reply('❌ حدث خطأ أثناء تحديث قاعدة البيانات');
      }
      break;
      
    case 'شائع':
    case 'popular':
      // عرض القنوات الشائعة
      let popularList = db.popular_channels.map((channel, index) => `${index + 1}. *${channel.name}* (${db.categories.find(cat => cat.id === channel.category)?.name || channel.category})`).join('\n');
      
      // إنشاء ملف M3U
      const playlistPath = createM3UPlaylist(db.popular_channels, 'popular_channels');
      
      // إرسال الملف
      await conn.sendFile(m.chat, playlistPath, path.basename(playlistPath), `القنوات الشائعة (${db.popular_channels.length} قناة)`, m);
      
      m.reply(`*🔝 القنوات الشائعة:*\n\n${popularList}\n\n_تم إرسال ملف M3U يحتوي على جميع القنوات الشائعة_`);
      break;
      
    case 'مساعدة':
    case 'help':
      // عرض قائمة الأوامر
      const helpText = `*📺 بوت قنوات IPTV - قائمة الأوامر:*

*.قنوات* - عرض قائمة فئات القنوات
*.رياضة* - عرض قنوات الرياضة
*.أفلام* - عرض قنوات الأفلام
*.أخبار* - عرض قنوات الأخبار
*.موسيقى* - عرض قنوات الموسيقى
*.أطفال* - عرض قنوات الأطفال
*.ترفيه* - عرض قنوات الترفيه
*.وثائقي* - عرض قنوات الوثائقية
*.عام* - عرض القنوات العامة
*.عربي* - عرض القنوات العربية
*.بحث <اسم القناة>* - البحث عن قناة
*.شائع* - عرض القنوات الشائعة
*.تحديث* - تحديث قاعدة بيانات القنوات (للمالك فقط)
*.مساعدة* - عرض هذه القائمة

_يمكنك استخدام الأوامر باللغة الإنجليزية أيضًا مثل .channels و .sports و .search_`;
      
      m.reply(helpText);
      break;
      
    default:
      // إذا لم يتم التعرف على الأمر، عرض رسالة المساعدة
      m.reply('❓ أمر غير معروف. استخدم *.مساعدة* لعرض قائمة الأوامر المتاحة.');
  }
};

handler.help = [
  'قنوات - عرض قائمة فئات القنوات',
  'رياضة - عرض قنوات الرياضة',
  'أفلام - عرض قنوات الأفلام',
  'أخبار - عرض قنوات الأخبار',
  'موسيقى - عرض قنوات الموسيقى',
  'أطفال - عرض قنوات الأطفال',
  'ترفيه - عرض قنوات الترفيه',
  'وثائقي - عرض قنوات الوثائقية',
  'عام - عرض القنوات العامة',
  'عربي - عرض القنوات العربية',
  'بحث <اسم القناة> - البحث عن قناة',
  'شائع - عرض القنوات الشائعة',
  'تحديث - تحديث قاعدة بيانات القنوات (للمالك فقط)',
  'مساعدة - عرض قائمة الأوامر'
];
handler.tags = ['tv', 'ch'];
handler.command = /^(قناة|ch|رياضة|sports|أفلام|movies|أخبار|news|موسيقى|music|أطفال|kids|ترفيه|entertainment|وثائقي|documentary|عام|general|عربي|arabic|بحث|search|تحديث|update|شائع|popular|مساعدة|help)$/i;

export default handler;
