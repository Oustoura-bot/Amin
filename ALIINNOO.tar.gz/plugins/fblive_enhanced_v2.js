import { spawn } from 'child_process';
import util from 'util';
import crypto from 'crypto';
// Import the updated subscription utility function
import { checkAndGrantSubscription } from './subscription_utils.js'; // Ensure this path is correct

// --- Configuration ---
const MAX_RETRIES = 3;
const RETRY_DELAY = 5000;
const MAX_CONCURRENT_STREAMS = 10; // Reduced based on previous discussion
const WATERMARK_PATH = '/home/container/WhatsApp Image 2025-05-03 at 00.14.43_61c296e8.jpg'; // Path to the NEW watermark image

// --- Stream Management --- START ---
global.runningFbStreams = global.runningFbStreams || {};

function generateStreamId() {
    return crypto.randomBytes(4).toString('hex');
}

// Define cleanupStream (no export needed)
function cleanupStream(streamId, conn, chatId, message, m) {
    const streamInfo = global.runningFbStreams[streamId];
    if (streamInfo) {
        // Ensure process is killed if it exists and hasn't exited
        if (streamInfo.process && streamInfo.process.exitCode === null) {
            console.log(`Killing process for stream [${streamId}] during cleanup.`);
            streamInfo.process.kill('SIGTERM'); // Attempt graceful termination first
        }
        delete global.runningFbStreams[streamId];
        console.log(`Cleaned up stream info for [${streamId}]`);
        if (conn && chatId && message && !streamInfo.restarting) { // Don't send cleanup message if restarting
            conn.reply(chatId, message, m);
        }
    } else {
        console.log(`Stream info for [${streamId}] already cleaned up or not found.`);
    }
}

// Define startStream (MODIFIED: added useWatermark parameter)
function startStream(streamId, ffmpegArgs, chatId, sourceUrl, fullDestinationUrl, userId, conn, m, useWatermark = true, isRetry = false, isReon = false) {
    console.log(`Attempting to start FFmpeg process [${streamId}] (Watermark: ${useWatermark}, Retry: ${isRetry}, Reon: ${isReon})`);

    let finalFfmpegArgs;

    if (useWatermark) {
        // Construct FFmpeg arguments WITH resized image watermark overlay (MODIFIED POSITION: y=10, x=W-w, SIZE: 180px width)
        finalFfmpegArgs = (ffmpegArgs && ffmpegArgs.length > 0) ? ffmpegArgs : [
            '-loglevel', 'error',
            '-reconnect', '1',
            '-reconnect_at_eof', '0',
            '-reconnect_streamed', '1',
            '-reconnect_delay_max', '10',
            '-timeout', '30000000',
            '-i', sourceUrl,              // Input 0: Main video source
            '-i', WATERMARK_PATH,         // Input 1: Watermark image
            // MODIFIED: Scale the watermark [1:v] to width 180px (height auto), then overlay it at W-w:10 (TOP RIGHT CORNER, 10px down)
            '-filter_complex', '[1:v]scale=250:-1[wm];[0:v][wm]overlay=W-w:40',
            '-c:v', 'libx264',            // Video codec (re-encoding required for overlay)
            '-preset', 'veryfast',       // Encoding speed preset
            '-crf', '23',                 // Constant Rate Factor (quality, lower is better, 18-28 is common)
            '-c:a', 'aac',                // Audio codec
            '-ar', '44100',              // Audio sample rate
            '-b:a', '128k',               // Audio bitrate
            '-f', 'flv',                  // Output format
            '-flvflags', 'no_duration_filesize',
            '-fflags', '+genpts',
            '-analyzeduration', '10M',    // Increased analysis duration
            '-probesize', '10M',          // Increased probe size
            fullDestinationUrl            // Output destination
        ];
    } else {
        // Construct FFmpeg arguments WITHOUT watermark (using copy for efficiency)
        finalFfmpegArgs = (ffmpegArgs && ffmpegArgs.length > 0) ? ffmpegArgs : [
            '-loglevel', 'error',
            '-reconnect', '1',
            '-reconnect_at_eof', '0',
            '-reconnect_streamed', '1',
            '-reconnect_delay_max', '10',
            '-timeout', '30000000',
            '-i', sourceUrl,              // Input 0: Main video source
            '-c:v', 'copy',               // Copy video stream (no re-encoding)
            '-c:a', 'copy',               // Copy audio stream (no re-encoding)
            '-f', 'flv',                  // Output format
            '-flvflags', 'no_duration_filesize',
            '-fflags', '+genpts',
            '-analyzeduration', '10M',    // Increased analysis duration
            '-probesize', '10M',          // Increased probe size
            fullDestinationUrl            // Output destination
        ];
    }

    const ffmpegProcess = spawn('ffmpeg', finalFfmpegArgs, {
        stdio: ['ignore', 'pipe', 'pipe']
    });

    // Update or initialize stream info
    if (!global.runningFbStreams[streamId] || isReon) {
         global.runningFbStreams[streamId] = {
            process: ffmpegProcess,
            sourceUrl: sourceUrl,
            destinationUrl: fullDestinationUrl,
            chatId: chatId,
            startTime: Date.now(),
            startedBy: userId,
            retries: 0,
            stopping: false,
            restarting: false,
            useWatermark: useWatermark // Store watermark preference for potential retries
        };
         console.log(`Initialized/Updated stream info for [${streamId}]`);
    } else {
        global.runningFbStreams[streamId].process = ffmpegProcess;
        global.runningFbStreams[streamId].stopping = false;
        global.runningFbStreams[streamId].restarting = false;
        console.log(`Updated process for stream [${streamId}] on retry.`);
    }

    ffmpegProcess.stderr.on('data', (data) => {
        // Limit stderr logging to prevent flooding
        console.error(`FFmpeg Stderr [${streamId}]: ${data.toString().substring(0, 250)}...`);
    });

    ffmpegProcess.on('close', (code) => {
        console.log(`FFmpeg process [${streamId}] exited with code ${code}`);
        const streamInfo = global.runningFbStreams[streamId];

        if (!streamInfo) {
             console.log(`Stream [${streamId}] info already cleaned up (on close).`);
             return;
        }

        if (streamInfo.restarting) {
            console.log(`Stream [${streamId}] is restarting, skipping close handling.`);
            // streamInfo.restarting = false; // Reset restarting flag after successful restart (handled in startStream call)
            return; // Don't cleanup or retry if restarting
        }

        if (streamInfo.stopping) {
            console.log(`Stream [${streamId}] stopped deliberately.`);
            const finalMessage = `*╔═════ ✅ تم الإيقاف ═════╗*\n*║* تم إيقاف البث ذو المعرف:\n*║* \n*║* *${streamId}*\n*║* \n*║* بنجاح بناءً على طلبك.\n*╚════════════════════╝*`;
            cleanupStream(streamId, conn, chatId, finalMessage, m);
            return;
        }

        // Handle unexpected exit (not deliberate stop, not restarting)
        if (code === 0) {
            console.log(`Stream [${streamId}] finished gracefully.`);
            const successMessage = `*╔═════ 🏁 انتهى البث ═════╗*\n*║* البث ذو المعرف:\n*║* \n*║* *${streamId}*\n*║* \n*║* قد انتهى بشكل طبيعي.\n*╚═══════════════════╝*`;
            cleanupStream(streamId, conn, chatId, successMessage, m);
        } else {
            streamInfo.retries = (streamInfo.retries || 0) + 1;
            console.error(`Stream [${streamId}] exited unexpectedly (code ${code}). Retry ${streamInfo.retries}/${MAX_RETRIES}.`);

            if (streamInfo.retries <= MAX_RETRIES) {
                 const retryMessage = `*╔═════ ⚠️ تنبيه ═════╗*\n*║* توقف البث [${streamId}] بشكل غير متوقع!\n*║* \n*║* جارٍ محاولة إعادة التشغيل تلقائياً...\n*║* *(المحاولة: ${streamInfo.retries}/${MAX_RETRIES})*\n*╚════════════════╝*`;
                 conn.reply(chatId, retryMessage, m);
                 streamInfo.restarting = true; // Set restarting flag before timeout
                 setTimeout(() => {
                     // Check if stream still exists and wasn't stopped deliberately during the delay
                     if (global.runningFbStreams[streamId] && !global.runningFbStreams[streamId].stopping) {
                        // Restart with the original watermark preference
                        startStream(streamId, [], chatId, streamInfo.sourceUrl, streamInfo.destinationUrl, userId, conn, m, streamInfo.useWatermark, true, false);
                     }
                 }, RETRY_DELAY);
            } else {
                console.error(`Stream [${streamId}] failed permanently after ${MAX_RETRIES} retries.`);
                const permFailMessage = `*╔═════ ❌ فشل دائم ═════╗*\n*║* فشل البث [${streamId}] بشكل دائم \n*║* بعد ${MAX_RETRIES} محاولات إعادة تشغيل.\n*║* \n*║* يرجى التحقق من رابط المصدر وإعدادات البث.\n*╚════════════════════╝*`;
                cleanupStream(streamId, conn, chatId, permFailMessage, m);
            }
        }
    });

    ffmpegProcess.on('error', (err) => {
        console.error(`Failed to start FFmpeg process [${streamId}]: ${err}`);
        const streamInfo = global.runningFbStreams[streamId];
        const spawnFailMessage = `*╔═════ ❌ فشل حاد ═════╗*\n*║* فشل في بدء عملية البث [${streamId}]:\n*║* \n*║* ${err.message}\n*║* \n*║* تأكد من تثبيت FFmpeg وصحة رابط المصدر.\n*║* لن تتم إعادة المحاولة تلقائياً.\n*╚══════════════════╝*`;
        if(streamInfo) streamInfo.restarting = false; // Ensure restarting flag is false on spawn error
        cleanupStream(streamId, conn, chatId, spawnFailMessage, m);
    });

     // Send initial message only when starting fresh or reon, not on automatic retry
     if (!isRetry) {
         const messageType = isReon ? "🔄 تحديث البث" : "🚀 بدء البث";
         // MODIFIED: Updated watermark status description
         const watermarkStatus = useWatermark ? "صورة (معدلة: عرض 180px، إزاحة 10px للأسفل)" : "لا يوجد";
         const startMessage = `*╔═════ ${messageType} ═════╗*\n*║* ${isReon ? 'جارٍ تحديث مصدر البث...' : 'جارٍ بدء البث المباشر...'}\n*║* \n*║* 🔗 *المصدر ${isReon ? 'الجديد' : ''}:* ${sourceUrl}\n*║* 🖼️ *العلامة المائية:* ${watermarkStatus}\n*║* 🆔 *معرف البث:* *${streamId}*
*║* 📍 *الوجهة:* ${fullDestinationUrl.replace(/\/[^\/]+$/, '/[مفتاح البث مخفي]')}\n*║* 🛡️ *الحالة:* جاري التهيئة...\n*╚════════════════════════════╝*`;
         m.reply(startMessage);
     }
}
// --- Stream Management --- END ---


// --- Main Handler (Handles .on, .fblive, .بث, .oni, .reon, .تحديث_البث) --- START ---
let handler = async (m, { conn, args, command, usedPrefix }) => {
    let userId = m.sender;
    let chatId = m.chat;

    // --- Subscription Check ---
    const subscriptionStatus = await checkAndGrantSubscription(userId, conn, m);
    if (subscriptionStatus.trialJustGranted) {
        console.log(`Trial just granted to ${userId}, proceeding with command.`);
    } else if (!subscriptionStatus.valid) {
        let replyMsg = "*╔═════ 🔒 صلاحية مطلوبة ═════╗*\n*║* ليس لديك الصلاحية لاستخدام هذا الأمر.\n*║* يتطلب اشتراكاً نشطاً أو أن تكون المالك.\n*╚════════════════════════╝*";
        if (subscriptionStatus.reason === 'Expired') {
            replyMsg = "*╔═════ 🚫 انتهى الاشتراك ═════╗*\n*║* عذراً، اشتراكك في خدمة البث قد انتهى.\n*║* يرجى تجديد اشتراكك للمتابعة.\n*╚════════════════════════╝*";
        } else if (subscriptionStatus.reason === 'Trial grant failed (write error)') {
             replyMsg = "*╔═════ ❌ خطأ ═════╗*\n*║* حدث خطأ أثناء محاولة منحك اشتراك تجريبي.\n*║* يرجى المحاولة مرة أخرى أو التواصل مع المالك.\n*╚════════════════╝*";
        }
        return conn.reply(chatId, replyMsg, m);
    }
    // --- End Subscription Check ---

    // --- Determine Action: Start New Stream, Start New (No Watermark), or Update Existing (Reon) ---
    const isReonCommand = ['reon', 'تحديث_البث'].includes(command);
    const isNoWatermarkCommand = command === 'oni';

    if (isReonCommand) {
        // --- Reon Logic --- (Remains largely the same, assumes reon always uses watermark)
        if (args.length < 2) {
            return m.reply(`*╔═════ ⚠️ استخدام خاطئ (.reon) ═════╗*\n*║* يرجى توفير معرف البث ورابط المصدر الجديد.\n*║* \n*║* *مثال:* \n*║* ${usedPrefix + command} <معرف_البث> <رابط_المصدر_الجديد>\n*╚════════════════════════════════╝*`);
        }

        const streamIdToUpdate = args[0];
        const newSourceUrl = args[1];

        const streamInfo = global.runningFbStreams ? global.runningFbStreams[streamIdToUpdate] : null;

        if (!streamInfo) {
            return m.reply(`*╔═════ ❓ بث غير موجود ═════╗*\n*║* لم يتم العثور على بث بالمعرف: *${streamIdToUpdate}*\n*║* تأكد من كتابة المعرف بشكل صحيح.\n*╚══════════════════════╝*`);
        }

        if (!subscriptionStatus.isOwner && streamInfo.startedBy !== userId) {
            return m.reply(`*╔═════ 🚫 غير مصرح ═════╗*\n*║* لا يمكنك تعديل هذا البث.\n*║* فقط المالك أو من بدأ البث يمكنه تعديله.\n*╚════════════════════╝*`);
        }

        // Validate new source URL (optional but good practice)
        try {
            new URL(newSourceUrl);
        } catch (_) {
            // Allow non-standard URLs but log a warning
            console.warn("New source URL might not be a standard URL:", newSourceUrl);
        }

        m.reply(`*╔═════ ⏳ جاري التحديث ═════╗*\n*║* تم العثور على البث [${streamIdToUpdate}].\n*║* جارٍ إيقاف العملية الحالية...\n*╚══════════════════════╝*`);

        streamInfo.restarting = true; // Set restarting flag

        // Kill the existing process
        if (streamInfo.process && streamInfo.process.exitCode === null) {
            console.log(`[Reon] Killing process for stream [${streamIdToUpdate}]`);
            streamInfo.process.kill('SIGTERM'); // Attempt graceful kill
        } else {
            console.log(`[Reon] Process for stream [${streamIdToUpdate}] already exited or not found.`);
        }

        // Wait briefly for the process to terminate
        await new Promise(resolve => setTimeout(resolve, 2000)); // 2 seconds delay

        console.log(`[Reon] Restarting stream [${streamIdToUpdate}] with new source: ${newSourceUrl}`);

        // Call internal startStream with isReon = true and useWatermark = true (default for reon)
        // The startStream function will now use the MODIFIED FFmpeg args with new watermark settings
        startStream(
            streamIdToUpdate,
            [], // Use default args with watermark
            streamInfo.chatId,
            newSourceUrl,
            streamInfo.destinationUrl, // Use stored full destination
            userId,
            conn,
            m,
            true, // useWatermark = true
            false, // Not a retry
            true   // Is a reon command
        );

    } else {
        // --- Start New Stream Logic (Handles .on, .fblive, .بث, .oni) --- 
        const currentStreamCount = Object.keys(global.runningFbStreams || {}).length;
        if (currentStreamCount >= MAX_CONCURRENT_STREAMS && !subscriptionStatus.isOwner) {
             return m.reply(`*╔═════ 🚦 البوت مشغول ═════╗*\n*║* عذراً، لقد وصلنا للحد الأقصى لعدد البثوث المتزامنة (${MAX_CONCURRENT_STREAMS}).\n*║* يرجى المحاولة لاحقاً أو الطلب من المالك زيادة الحد.\n*╚══════════════════════╝*`);
        }

        if (args.length < 3) {
            const exampleCmd = isNoWatermarkCommand ? '.oni' : '.on';
            return m.reply(`*╔═════ ⚠️ استخدام خاطئ (${exampleCmd}) ═════╗*\n*║* يرجى توفير جميع المعلومات المطلوبة.\n*║* \n*║* *مثال:* \n*║* ${usedPrefix + exampleCmd} rtmps://... <مفتاح_البث> <رابط_المصدر>\n*╚════════════════════════════════╝*`);
        }

        let rtmpUrlBase = args[0];
        let streamKey = args[1];
        let sourceUrl = args[2];

        // Validate RTMP URL base
        if (!rtmpUrlBase.startsWith('rtmps://') && !rtmpUrlBase.startsWith('rtmp://')) {
            return m.reply('*╔═════ ⚠️ خطأ ═════╗*\n*║* عنوان RTMP الأساسي غير صالح.\n*║* يجب أن يبدأ بـ `rtmp://` أو `rtmps://`\n*╚════════════════╝*');
        }

         // Validate source URL (optional but good practice)
         try {
            new URL(sourceUrl);
         } catch (_) {
            // Allow non-standard URLs but log a warning
            console.warn("Source URL might not be a standard URL:", sourceUrl);
         }

        // Construct the full destination URL
        const fullDestinationUrl = rtmpUrlBase.endsWith('/') ? `${rtmpUrlBase}${streamKey}` : `${rtmpUrlBase}/${streamKey}`;
        const streamId = generateStreamId();

        // Call internal startStream with isReon = false
        // Pass useWatermark based on the command used
        // The startStream function will now use the MODIFIED FFmpeg args with new watermark settings if !isNoWatermarkCommand
        startStream(streamId, [], chatId, sourceUrl, fullDestinationUrl, userId, conn, m, !isNoWatermarkCommand, false, false);
                                                                                             // ^^^^ useWatermark is true unless command is .oni
    }
};
// --- Main Handler --- END ---

// FIX: Removed trailing \n from help strings to avoid potential parsing errors
// MODIFIED: Updated help text for watermark description
handler.help = [
    'fblive <rtmp_url_base> <stream_key> <source_url> (لبدء بث جديد مع علامة مائية معدلة: عرض 180px، إزاحة 10px للأسفل)',
    'oni <rtmp_url_base> <stream_key> <source_url> (لبدء بث جديد بدون علامة مائية)',
    'reon <stream_id> <new_source_url> (لتحديث مصدر بث قائم مع علامة مائية معدلة: عرض 180px، إزاحة 10px للأسفل)'
];
handler.tags = ['tools', 'streaming'];
// Add oni and reon commands to the list
handler.command = ['fblive', 'on', 'بث', 'oni', 'reon', 'تحديث_البث'];

export default handler; // Default export for the unified handler

