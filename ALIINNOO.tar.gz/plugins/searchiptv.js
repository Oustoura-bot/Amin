// بسم الله الرحمن الرحيم ✨✨✨
// أمر للبحث عن قنوات IPTV بشكل عام باستخدام مصادر متعددة والتحقق من الصلاحية

import axios from 'axios';
import cheerio from 'cheerio';
import scrapeStreamtestGeneric from '../lib/scrape_streamtest_generic.js'; // استيراد وظيفة الاستخراج العامة

// دالة مساعدة للتأخير
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// دالة للتحقق من صلاحية رابط M3U8 (تبقى كما هي)
async function validateChannelLink(url, timeout = 5000) {
    console.log(`[VALIDATE DEBUG] Checking link: ${url}`);
    try {
        const response = await axios.head(url, {
            timeout: timeout,
            headers: { 'User-Agent': 'Mozilla/5.0' },
            validateStatus: (status) => status >= 200 && status < 500,
        });
        if (response.status >= 200 && response.status < 300) {
            console.log(`[VALIDATE DEBUG] Link OK (Status ${response.status}): ${url}`);
            return true;
        } else if (response.status === 403) {
            console.log(`[VALIDATE DEBUG] Link Forbidden (Status ${response.status}), might work: ${url}`);
            return true;
        } else {
            console.log(`[VALIDATE DEBUG] Link Failed (Status ${response.status}): ${url}`);
            return false;
        }
    } catch (error) {
        if (axios.isAxiosError(error)) {
            if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
                console.log(`[VALIDATE DEBUG] Link Timeout: ${url}`);
            } else if (error.response) {
                console.log(`[VALIDATE DEBUG] Link Error (Status ${error.response.status}): ${url}`);
            } else {
                console.log(`[VALIDATE DEBUG] Link Network Error: ${url}`, error.message);
            }
        } else {
            console.log(`[VALIDATE DEBUG] Link Unknown Error: ${url}`, error.message);
        }
        return false;
    }
}

// دالة جلب وتحليل ملف M3U (نسخة معدلة للبحث العام)
async function fetchAndParseM3U(url, searchQuery) {
    console.log(`[M3U PARSE DEBUG] Attempting to fetch channels matching "${searchQuery}" from: ${url}`);
    try {
        const response = await axios.get(url, {
            timeout: 30000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        console.log(`[M3U PARSE DEBUG] Successfully fetched from ${url}. Status: ${response.status}`);
        const m3uContent = response.data;
        if (!m3uContent || typeof m3uContent !== 'string') {
            console.error(`[M3U PARSE DEBUG] M3U content is empty or not a string from ${url}.`);
            return [];
        }
        const lines = m3uContent.split('\n');
        const channels = [];
        let currentChannel = {};
        const queryLower = searchQuery.toLowerCase(); // تحويل نص البحث إلى حروف صغيرة مرة واحدة

        for (const line of lines) {
            const trimmedLine = line.trim();
            if (trimmedLine.startsWith('#EXTINF:')) {
                currentChannel = {};
                const titleMatch = trimmedLine.match(/,(.+)$/);
                let title = titleMatch ? titleMatch[1].trim() : 'قناة غير معروفة';
                const tvgNameMatch = trimmedLine.match(/tvg-name="([^\"]+)"/);
                if (tvgNameMatch && tvgNameMatch[1]) {
                    title = tvgNameMatch[1].trim();
                }
                // التصفية بناءً على نص البحث المقدم
                if (title.toLowerCase().includes(queryLower)) {
                    currentChannel.title = title;
                } else {
                    currentChannel = {}; // إعادة تعيين إذا لم يتطابق العنوان
                }
            } else if (currentChannel.title && trimmedLine && !trimmedLine.startsWith('#') && trimmedLine.toLowerCase().includes('.m3u8')) {
                if (trimmedLine.startsWith('http://') || trimmedLine.startsWith('https://')) {
                    currentChannel.url = trimmedLine;
                    // التحقق من عدم وجود الرابط مسبقًا في القائمة المؤقتة لهذا المصدر
                    if (!channels.some(ch => ch.url === currentChannel.url)) {
                        channels.push({ ...currentChannel });
                    }
                    currentChannel = {}; // إعادة تعيين بعد إضافة القناة
                }
            }
        }
        console.log(`[M3U PARSE DEBUG] Parsed ${channels.length} channels matching "${searchQuery}" from ${url}`);
        return channels;
    } catch (error) {
        console.error(`[M3U PARSE DEBUG] Error fetching or parsing M3U from ${url}:`, error.message);
        return [];
    }
}

// المعالج الرئيسي لأمر البحث العام (مثل .searchiptv)
let handler = async (m, { conn, text, usedPrefix, command }) => {
    const query = text.trim();
    if (!query) {
        return m.reply(`*⚠️ الاستخدام:* ${usedPrefix + command} [اسم القناة]
*مثال:* ${usedPrefix + command} ssc`);
    }

    console.log(`[IPTV SEARCH DEBUG] Command received: ${usedPrefix + command} ${query}`);
    const CHUNK_SIZE = 5;
    const MESSAGE_DELAY = 1500;
    const VALIDATION_CONCURRENCY = 5;
    const VALIDATION_UPDATE_INTERVAL = VALIDATION_CONCURRENCY * 5;
    const STREAMTEST_MAX_PAGES = 3;

    // مصادر M3U (يمكن توسيعها لاحقًا)
    const M3U_SOURCE_URLS = [
        'https://iptv-org.github.io/iptv/index.m3u', // المصدر الرئيسي
        'https://iptv-org.github.io/iptv/categories/sports.m3u', // رياضة
        'https://iptv-org.github.io/iptv/categories/news.m3u', // أخبار
        'https://iptv-org.github.io/iptv/countries/sa.m3u', // السعودية (لـ SSC)
        // يمكن إضافة المزيد من الفئات أو الدول هنا
    ];

    await m.reply(`⏳ *لحظات من فضلك...*
1️⃣ جاري البحث عن قنوات تطابق "${query}" في ${M3U_SOURCE_URLS.length} ملفات M3U...
2️⃣ جاري استخراج الروابط من streamtest.in (حتى ${STREAMTEST_MAX_PAGES} صفحات)...
3️⃣ سيتم التحقق من صلاحية الروابط المجمعة (قد يستغرق هذا بعض الوقت)... 📺`);

    let allPotentialChannels = [];
    let m3uFetchErrors = 0;
    let streamtestScrapeError = false;

    // 1. جلب وتحليل من مصادر M3U بناءً على query
    const m3uResults = await Promise.allSettled(M3U_SOURCE_URLS.map(url => fetchAndParseM3U(url, query)));
    m3uResults.forEach((result, index) => {
        if (result.status === 'fulfilled' && Array.isArray(result.value)) {
            console.log(`[IPTV SEARCH DEBUG] Successfully processed M3U source: ${M3U_SOURCE_URLS[index]}. Found ${result.value.length} channels matching "${query}".`);
            allPotentialChannels = allPotentialChannels.concat(result.value);
        } else {
            m3uFetchErrors++;
            console.error(`[IPTV SEARCH DEBUG] Failed to process M3U source: ${M3U_SOURCE_URLS[index]}. Reason: ${result.reason || 'Unknown error'}`);
        }
    });

    // 2. استخراج الروابط من streamtest.in (نسخة عامة)
    let scrapedLinks = [];
    try {
        scrapedLinks = await scrapeStreamtestGeneric(STREAMTEST_MAX_PAGES);
        console.log(`[IPTV SEARCH DEBUG] Successfully scraped ${scrapedLinks.length} M3U8 links from streamtest.in.`);
        // تصفية الروابط المستخرجة بناءً على query
        scrapedLinks.forEach(link => {
            // تصفية أولية بناءً على الرابط نفسه أو اسم نطاق معروف
            if (link.toLowerCase().includes(query.toLowerCase())) {
                 allPotentialChannels.push({ title: `${query}؟ (من streamtest.in)`, url: link });
            }
        });
    } catch (error) {
        streamtestScrapeError = true;
        console.error(`[IPTV SEARCH DEBUG] Failed to scrape links from streamtest.in:`, error.message);
    }

    // 3. إزالة التكرارات بناءً على URL
    const uniqueChannelsMap = new Map();
    allPotentialChannels.forEach(channel => {
        if (!uniqueChannelsMap.has(channel.url)) {
            uniqueChannelsMap.set(channel.url, channel);
        }
    });
    const uniqueChannels = Array.from(uniqueChannelsMap.values());

    if (uniqueChannels.length === 0) {
        console.log(`[IPTV SEARCH DEBUG] No unique potential channels found for "${query}" after combining sources.`);
        let errorMsg = `*💨 لم يتم العثور على قنوات محتملة تطابق "${query}" بعد البحث في ${M3U_SOURCE_URLS.length} ملفات M3U واستخراج الروابط من streamtest.in.*`;
        if (m3uFetchErrors > 0) {
            errorMsg += `\n(فشل جلب البيانات من ${m3uFetchErrors} ملفات M3U)`;
        }
        if (streamtestScrapeError) {
             errorMsg += `\n(فشل استخراج الروابط من streamtest.in)`;
        }
        return m.reply(errorMsg);
    }

    console.log(`[IPTV SEARCH DEBUG] Found ${uniqueChannels.length} unique potential channels for "${query}". Starting validation...`);
    await m.reply(`🔍 تم العثور على ${uniqueChannels.length} قناة فريدة محتملة تطابق "${query}". جاري التحقق من صلاحية الروابط (قد يستغرق هذا بعض الوقت)...`);

    // 4. التحقق من صلاحية الروابط بالتوازي المحدود مع تحديثات التقدم
    const validatedChannels = [];
    for (let i = 0; i < uniqueChannels.length; i += VALIDATION_CONCURRENCY) {
        const batch = uniqueChannels.slice(i, i + VALIDATION_CONCURRENCY);
        const validationResults = await Promise.allSettled(batch.map(channel => validateChannelLink(channel.url)));

        validationResults.forEach((result, index) => {
            if (result.status === 'fulfilled' && result.value === true) {
                validatedChannels.push(batch[index]);
            }
        });
        console.log(`[IPTV SEARCH DEBUG] Validated batch ${Math.floor(i / VALIDATION_CONCURRENCY) + 1}. Current valid count for "${query}": ${validatedChannels.length}`);

        const processedCount = i + batch.length;
        if (processedCount % VALIDATION_UPDATE_INTERVAL === 0 && processedCount < uniqueChannels.length) {
            try {
                await m.reply(`⏳ جاري التحقق من الروابط لـ "${query}"... (${processedCount}/${uniqueChannels.length})`);
            } catch (e) {
                console.error("[IPTV SEARCH DEBUG] Failed to send progress update:", e);
            }
        }
        await delay(500);
    }

    // 5. فرز القنوات الصالحة وعرضها
    validatedChannels.sort((a, b) => a.title.localeCompare(b.title));

    if (validatedChannels.length === 0) {
        console.log(`[IPTV SEARCH DEBUG] No working channels found for "${query}" after validation.`);
        let errorMsg = `*💨 لم يتم العثور على قنوات *تعمل حالياً* تطابق "${query}" بعد التحقق من ${uniqueChannels.length} رابط محتمل.*`;
        if (m3uFetchErrors > 0) {
            errorMsg += `\n(فشل جلب البيانات من ${m3uFetchErrors} ملفات M3U)`;
        }
         if (streamtestScrapeError) {
             errorMsg += `\n(فشل استخراج الروابط من streamtest.in)`;
        }
        return m.reply(errorMsg);
    }

    const totalChannels = validatedChannels.length;
    const numChunks = Math.ceil(totalChannels / CHUNK_SIZE);
    console.log(`[IPTV SEARCH DEBUG] Found ${totalChannels} working channels for "${query}". Preparing to send in ${numChunks} chunks.`);

    let successMsg = `✅ *ممتاز!* تم العثور والتحقق من *${totalChannels}* قناة محتملة تطابق "${query}" *تعمل حالياً*.`;
    successMsg += `\n(المصادر: ${M3U_SOURCE_URLS.length} ملفات M3U + streamtest.in)`;
    if (m3uFetchErrors > 0) {
        successMsg += `\n(ملاحظة: فشل جلب البيانات من ${m3uFetchErrors} ملفات M3U)`;
    }
    if (streamtestScrapeError) {
        successMsg += `\n(ملاحظة: فشل استخراج الروابط من streamtest.in)`;
    }
    successMsg += `\nسيتم إرسالها الآن في *${numChunks}* رسالة/رسائل. 📺`;
    await m.reply(successMsg);
    await delay(MESSAGE_DELAY);

    for (let i = 0; i < totalChannels; i += CHUNK_SIZE) {
        const chunk = validatedChannels.slice(i, i + CHUNK_SIZE);
        let chunkMsg = `🏆 *قنوات عاملة تطابق "${query}" (الجزء ${Math.floor(i / CHUNK_SIZE) + 1}/${numChunks})*\n\n`;
        chunk.forEach((channel, index) => {
            const displayTitle = channel.title.replace(/\[.*?\]/g, '').trim();
            chunkMsg += `${i + index + 1}. ${displayTitle}\n🔗 ${channel.url}\n\n`;
        });
        try {
            await m.reply(chunkMsg.trim());
            console.log(`[IPTV SEARCH DEBUG] Sent chunk ${Math.floor(i / CHUNK_SIZE) + 1}/${numChunks} for "${query}"`);
        } catch (e) {
            console.error(`[IPTV SEARCH DEBUG] Error sending chunk ${Math.floor(i / CHUNK_SIZE) + 1} for "${query}":`, e);
            await m.reply(`حدث خطأ أثناء إرسال الجزء ${Math.floor(i / CHUNK_SIZE) + 1}.`);
        }
        if (i + CHUNK_SIZE < totalChannels) {
            await delay(MESSAGE_DELAY);
        }
    }
    console.log(`[IPTV SEARCH DEBUG] Finished sending all chunks for "${query}".`);
};

// --- البيانات الوصفية لـ Silana-Lite ---
handler.command = /^(searchiptv|findiptv|iptvsearch|بحث_قنوات)$/i;
handler.help = ['searchiptv [اسم القناة]'];
handler.tags = ['tools', 'search', 'iptv'];
handler.limit = true;

export default handler;

