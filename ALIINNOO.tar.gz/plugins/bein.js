// بسم الله الرحمن الرحيم ✨✨✨
// أمر للبحث عن قنوات رياضية مشهورة (beIN, SSC, Sky, ESPN, etc.) من مصادر متعددة مع التحقق من الصلاحية

import axios from 'axios';
import cheerio from 'cheerio';
// استخدام وظيفة الاستخراج العامة
import scrapeStreamtestGeneric from '../lib/scrape_streamtest_generic.js';

// دالة مساعدة للتأخير
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// دالة للتحقق من صلاحية رابط M3U8 (تبقى كما هي)
async function validateChannelLink(url, timeout = 5000) {
    console.log(`[VALIDATE DEBUG] Checking link: ${url}`);
    try {
        const response = await axios.head(url, {
            timeout: timeout,
            headers: { 'User-Agent': 'Mozilla/5.0' },
            validateStatus: (status) => status >= 200 && status < 500,
        });
        if (response.status >= 200 && response.status < 300) {
            console.log(`[VALIDATE DEBUG] Link OK (Status ${response.status}): ${url}`);
            return true;
        } else if (response.status === 403) {
            console.log(`[VALIDATE DEBUG] Link Forbidden (Status ${response.status}), might work: ${url}`);
            return true;
        } else {
            console.log(`[VALIDATE DEBUG] Link Failed (Status ${response.status}): ${url}`);
            return false;
        }
    } catch (error) {
        if (axios.isAxiosError(error)) {
            if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
                console.log(`[VALIDATE DEBUG] Link Timeout: ${url}`);
            } else if (error.response) {
                console.log(`[VALIDATE DEBUG] Link Error (Status ${error.response.status}): ${url}`);
            } else {
                console.log(`[VALIDATE DEBUG] Link Network Error: ${url}`, error.message);
            }
        } else {
            console.log(`[VALIDATE DEBUG] Link Unknown Error: ${url}`, error.message);
        }
        return false;
    }
}

// قائمة الكلمات المفتاحية للقنوات الرياضية المشهورة (بالحروف الصغيرة)
const SPORTS_KEYWORDS = [
    'bein sport',
    'ssc',
    'sky sport',
    'espn',
    'eurosport',
    'bt sport',
    'dazn',
    'premier sport',
    'sport tv', // برتغالية
    'arena sport',
    'super sport', // ألبانيا/أفريقيا
    'ad sport', // أبوظبي الرياضية
    'dubai sport', // دبي الرياضية
    'alkass', // الكأس
    // يمكن إضافة المزيد هنا
];

// دالة جلب وتحليل ملف M3U (معدلة للبحث عن قائمة كلمات مفتاحية)
async function fetchAndParseSportsM3U(url, keywords) {
    console.log(`[SPORTS M3U DEBUG] Attempting to fetch channels matching keywords from: ${url}`);
    try {
        const response = await axios.get(url, {
            timeout: 30000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        console.log(`[SPORTS M3U DEBUG] Successfully fetched from ${url}. Status: ${response.status}`);
        const m3uContent = response.data;
        if (!m3uContent || typeof m3uContent !== 'string') {
            console.error(`[SPORTS M3U DEBUG] M3U content is empty or not a string from ${url}.`);
            return [];
        }
        const lines = m3uContent.split('\n');
        const channels = [];
        let currentChannel = {};

        for (const line of lines) {
            const trimmedLine = line.trim();
            if (trimmedLine.startsWith('#EXTINF:')) {
                currentChannel = {};
                const titleMatch = trimmedLine.match(/,(.+)$/);
                let title = titleMatch ? titleMatch[1].trim() : 'قناة غير معروفة';
                const tvgNameMatch = trimmedLine.match(/tvg-name="([^\"]+)"/);
                if (tvgNameMatch && tvgNameMatch[1]) {
                    title = tvgNameMatch[1].trim();
                }
                const titleLower = title.toLowerCase();
                // التحقق مما إذا كان العنوان يحتوي على أي من الكلمات المفتاحية المحددة
                if (keywords.some(keyword => titleLower.includes(keyword))) {
                    currentChannel.title = title;
                } else {
                    currentChannel = {}; // إعادة تعيين إذا لم يتطابق العنوان
                }
            } else if (currentChannel.title && trimmedLine && !trimmedLine.startsWith('#') && trimmedLine.toLowerCase().includes('.m3u8')) {
                if (trimmedLine.startsWith('http://') || trimmedLine.startsWith('https://')) {
                    currentChannel.url = trimmedLine;
                    if (!channels.some(ch => ch.url === currentChannel.url)) {
                        channels.push({ ...currentChannel });
                    }
                    currentChannel = {};
                }
            }
        }
        console.log(`[SPORTS M3U DEBUG] Parsed ${channels.length} channels matching keywords from ${url}`);
        return channels;
    } catch (error) {
        console.error(`[SPORTS M3U DEBUG] Error fetching or parsing M3U from ${url}:`, error.message);
        return [];
    }
}

// المعالج الرئيسي لأمر .bein (معدل للبحث عن قنوات رياضية عالمية)
let handler = async (m, { conn, usedPrefix, command }) => {
    console.log(`[SPORTS DEBUG] Command received: ${usedPrefix + command}`);
    const CHUNK_SIZE = 5;
    const MESSAGE_DELAY = 1500;
    const VALIDATION_CONCURRENCY = 5;
    const VALIDATION_UPDATE_INTERVAL = VALIDATION_CONCURRENCY * 5;
    const STREAMTEST_MAX_PAGES = 3;

    // مصادر M3U (التركيز على المصادر العامة والرياضية)
    const M3U_SOURCE_URLS = [
        'https://iptv-org.github.io/iptv/index.m3u',
        'https://iptv-org.github.io/iptv/categories/sports.m3u',
        'https://iptv-org.github.io/iptv/countries/sa.m3u', // السعودية قد تحتوي SSC
        'https://iptv-org.github.io/iptv/countries/gb.m3u', // بريطانيا لـ Sky/BT
        'https://iptv-org.github.io/iptv/countries/us.m3u', // أمريكا لـ ESPN
        'https://iptv-org.github.io/iptv/countries/qa.m3u', // قطر لـ beIN/Alkass
        'https://iptv-org.github.io/iptv/countries/ae.m3u', // الإمارات لـ AD/Dubai Sports
    ];

    await m.reply(`⏳ *لحظات من فضلك...*
1️⃣ جاري البحث عن قنوات رياضية مشهورة (beIN, SSC, Sky, ...) في ${M3U_SOURCE_URLS.length} ملفات M3U...
2️⃣ جاري استخراج الروابط من streamtest.in (حتى ${STREAMTEST_MAX_PAGES} صفحات)...
3️⃣ سيتم التحقق من صلاحية الروابط المجمعة (قد يستغرق هذا بعض الوقت)... ⚽`);

    let allPotentialChannels = [];
    let m3uFetchErrors = 0;
    let streamtestScrapeError = false;

    // 1. جلب وتحليل من مصادر M3U باستخدام قائمة الكلمات المفتاحية
    const m3uResults = await Promise.allSettled(M3U_SOURCE_URLS.map(url => fetchAndParseSportsM3U(url, SPORTS_KEYWORDS)));
    m3uResults.forEach((result, index) => {
        if (result.status === 'fulfilled' && Array.isArray(result.value)) {
            console.log(`[SPORTS DEBUG] Successfully processed M3U source: ${M3U_SOURCE_URLS[index]}. Found ${result.value.length} matching sports channels.`);
            allPotentialChannels = allPotentialChannels.concat(result.value);
        } else {
            m3uFetchErrors++;
            console.error(`[SPORTS DEBUG] Failed to process M3U source: ${M3U_SOURCE_URLS[index]}. Reason: ${result.reason || 'Unknown error'}`);
        }
    });

    // 2. استخراج الروابط من streamtest.in (نسخة عامة)
    let scrapedLinks = [];
    try {
        scrapedLinks = await scrapeStreamtestGeneric(STREAMTEST_MAX_PAGES);
        console.log(`[SPORTS DEBUG] Successfully scraped ${scrapedLinks.length} M3U8 links from streamtest.in.`);
        // تصفية الروابط المستخرجة بناءً على قائمة الكلمات المفتاحية
        scrapedLinks.forEach(link => {
            const linkLower = link.toLowerCase();
            // التحقق مما إذا كان الرابط يحتوي على أي من الكلمات المفتاحية
            if (SPORTS_KEYWORDS.some(keyword => linkLower.includes(keyword.replace(/\s+/g, '')))) { // إزالة المسافات من الكلمة المفتاحية للمقارنة بالرابط
                 // محاولة استنتاج اسم القناة من الرابط
                 let inferredTitle = 'قناة رياضية؟';
                 for (const keyword of SPORTS_KEYWORDS) {
                     if (linkLower.includes(keyword.replace(/\s+/g, ''))) {
                         inferredTitle = keyword.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') + '?'; // تحويل الكلمة المفتاحية لعنوان مبدئي
                         break;
                     }
                 }
                 allPotentialChannels.push({ title: `${inferredTitle} (من streamtest.in)`, url: link });
            }
        });
    } catch (error) {
        streamtestScrapeError = true;
        console.error(`[SPORTS DEBUG] Failed to scrape links from streamtest.in:`, error.message);
    }

    // 3. إزالة التكرارات بناءً على URL
    const uniqueChannelsMap = new Map();
    allPotentialChannels.forEach(channel => {
        if (!uniqueChannelsMap.has(channel.url)) {
            uniqueChannelsMap.set(channel.url, channel);
        }
    });
    const uniqueChannels = Array.from(uniqueChannelsMap.values());

    if (uniqueChannels.length === 0) {
        console.log(`[SPORTS DEBUG] No unique potential sports channels found after combining sources.`);
        let errorMsg = `*💨 لم يتم العثور على قنوات رياضية مشهورة محتملة بعد البحث في ${M3U_SOURCE_URLS.length} ملفات M3U واستخراج الروابط من streamtest.in.*`;
        if (m3uFetchErrors > 0) {
            errorMsg += `\n(فشل جلب البيانات من ${m3uFetchErrors} ملفات M3U)`;
        }
        if (streamtestScrapeError) {
             errorMsg += `\n(فشل استخراج الروابط من streamtest.in)`;
        }
        return m.reply(errorMsg);
    }

    console.log(`[SPORTS DEBUG] Found ${uniqueChannels.length} unique potential sports channels. Starting validation...`);
    await m.reply(`🔍 تم العثور على ${uniqueChannels.length} قناة رياضية فريدة محتملة. جاري التحقق من صلاحية الروابط (قد يستغرق هذا بعض الوقت)...`);

    // 4. التحقق من صلاحية الروابط بالتوازي المحدود مع تحديثات التقدم
    const validatedChannels = [];
    for (let i = 0; i < uniqueChannels.length; i += VALIDATION_CONCURRENCY) {
        const batch = uniqueChannels.slice(i, i + VALIDATION_CONCURRENCY);
        const validationResults = await Promise.allSettled(batch.map(channel => validateChannelLink(channel.url)));

        validationResults.forEach((result, index) => {
            if (result.status === 'fulfilled' && result.value === true) {
                validatedChannels.push(batch[index]);
            }
        });
        console.log(`[SPORTS DEBUG] Validated batch ${Math.floor(i / VALIDATION_CONCURRENCY) + 1}. Current valid count: ${validatedChannels.length}`);

        const processedCount = i + batch.length;
        if (processedCount % VALIDATION_UPDATE_INTERVAL === 0 && processedCount < uniqueChannels.length) {
            try {
                await m.reply(`⏳ جاري التحقق من روابط القنوات الرياضية... (${processedCount}/${uniqueChannels.length})`);
            } catch (e) {
                console.error("[SPORTS DEBUG] Failed to send progress update:", e);
            }
        }
        await delay(500);
    }

    // 5. فرز القنوات الصالحة وعرضها
    validatedChannels.sort((a, b) => a.title.localeCompare(b.title));

    if (validatedChannels.length === 0) {
        console.log(`[SPORTS DEBUG] No working sports channels found after validation.`);
        let errorMsg = `*💨 لم يتم العثور على قنوات رياضية مشهورة *تعمل حالياً* بعد التحقق من ${uniqueChannels.length} رابط محتمل.*`;
        if (m3uFetchErrors > 0) {
            errorMsg += `\n(فشل جلب البيانات من ${m3uFetchErrors} ملفات M3U)`;
        }
         if (streamtestScrapeError) {
             errorMsg += `\n(فشل استخراج الروابط من streamtest.in)`;
        }
        return m.reply(errorMsg);
    }

    const totalChannels = validatedChannels.length;
    const numChunks = Math.ceil(totalChannels / CHUNK_SIZE);
    console.log(`[SPORTS DEBUG] Found ${totalChannels} working sports channels. Preparing to send in ${numChunks} chunks.`);

    let successMsg = `✅ *ممتاز!* تم العثور والتحقق من *${totalChannels}* قناة رياضية مشهورة محتملة *تعمل حالياً*.`;
    successMsg += `\n(المصادر: ${M3U_SOURCE_URLS.length} ملفات M3U + streamtest.in)`;
    if (m3uFetchErrors > 0) {
        successMsg += `\n(ملاحظة: فشل جلب البيانات من ${m3uFetchErrors} ملفات M3U)`;
    }
    if (streamtestScrapeError) {
        successMsg += `\n(ملاحظة: فشل استخراج الروابط من streamtest.in)`;
    }
    successMsg += `\nسيتم إرسالها الآن في *${numChunks}* رسالة/رسائل. 📺`;
    await m.reply(successMsg);
    await delay(MESSAGE_DELAY);

    for (let i = 0; i < totalChannels; i += CHUNK_SIZE) {
        const chunk = validatedChannels.slice(i, i + CHUNK_SIZE);
        let chunkMsg = `🏆 *قنوات رياضية عاملة (الجزء ${Math.floor(i / CHUNK_SIZE) + 1}/${numChunks})*\n\n`;
        chunk.forEach((channel, index) => {
            const displayTitle = channel.title.replace(/\[.*?\]/g, '').trim();
            chunkMsg += `${i + index + 1}. ${displayTitle}\n🔗 ${channel.url}\n\n`;
        });
        try {
            await m.reply(chunkMsg.trim());
            console.log(`[SPORTS DEBUG] Sent chunk ${Math.floor(i / CHUNK_SIZE) + 1}/${numChunks}`);
        } catch (e) {
            console.error(`[SPORTS DEBUG] Error sending chunk ${Math.floor(i / CHUNK_SIZE) + 1}:`, e);
            await m.reply(`حدث خطأ أثناء إرسال الجزء ${Math.floor(i / CHUNK_SIZE) + 1}.`);
        }
        if (i + CHUNK_SIZE < totalChannels) {
            await delay(MESSAGE_DELAY);
        }
    }
    console.log(`[SPORTS DEBUG] Finished sending all chunks.`);
};

// --- البيانات الوصفية لـ Silana-Lite ---
// الأوامر تبقى كما هي (.bein, .binsport, إلخ)
handler.command = /^(bein|binsport|بي_ان|بين_سبورت)$/i;
handler.help = ['bein']; // المساعدة تشير إلى الأمر الرئيسي
handler.tags = ['tools', 'search', 'iptv', 'sports']; // إضافة وسم sports
handler.limit = true;

export default handler;

