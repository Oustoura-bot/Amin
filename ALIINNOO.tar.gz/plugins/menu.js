// instagram.com/noureddine_ouafy
import moment from 'moment-timezone';
import PhoneNumber from 'awesome-phonenumber';
import fs from 'fs';
import fetch from 'node-fetch';

// --- تصميم القائمة الاحترافي ---
const design = {
    header: "*❖═══════ •⊰ ✨ *ALINO-BOT-LIVE* ✨⊱• ═══════❖*",
    greeting: (name) => `أهلاً بك يا ${name}! 👋`, // تحية مخصصة
    dateTime: (week, date) => `📅 ${week}, ${date}`,
    botInfo: (namebot, version, uptime, totalFitur, userReg, tUser) => 
`╭─「 *معلومات البوت* 」
│ 🤖 *الاسم:* ${namebot}
│ ⚙️ *الإصدار:* ${version || '1.0'}
│ 🕒 *وقت التشغيل:* ${uptime}
│ 💡 *إجمالي الميزات:* ${totalFitur}
│ 👥 *المستخدمون المسجلون:* ${userReg} / ${tUser}
╰────────────•`, // معلومات البوت بتنسيق أفضل
    menuSectionHeader: (tag) => `╭─「 *${tag.toUpperCase()}* 」`, // رأس قسم القائمة
    menuItem: (helpItem, premium, limit) => `│ ✨ *.${helpItem}* ${premium ? '💎' : ''}${limit ? '⚡' : ''}`, // عنصر القائمة مع رموز للميزات الخاصة
    menuSectionFooter: "╰────────────•", // نهاية قسم القائمة
    listAllCommands: "*قائمة الأوامر الكاملة:*",
    footer: (wm) => `*${wm}*\n*❖═══════ •⊰ شكراً لاستخدامك ⊱• ═══════❖*`, // تذييل القائمة
    prompt: "*اختر القسم المطلوب من القائمة أدناه:* 👇",
    tagDescription: (tag, count) => `*${tag}* - ${count} ميزة`, // وصف القسم في قائمة الأزرار
    buttonListTitle: "*📜 قائمة الأوامر الرئيسية 📜*",
    buttonSectionTitle: "*🗂️ أقسام الأوامر 🗂️*",
    buttonInfoTitle: "*ℹ️ معلومات إضافية ℹ️*",
    buttonAllTitle: "*📚 عرض كل الأوامر 📚*",
};

// --- نهاية تصميم القائمة ---

let handler = async (m, { conn, usedPrefix, command, args }) => {
    const cmd = args[0] || 'list';
    let type = (args[0] || '').toLowerCase();
    let _menu = global.db.data.settings[conn.user.jid]; // إعدادات عرض القائمة
    let d = new Date(new Date + 3600000); // توقيت غرينتش +1
    let locale = 'ar'; // استخدام اللغة العربية للتاريخ
    let week = d.toLocaleDateString(locale, { weekday: 'long' });
    let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
    let time = d.toLocaleTimeString(locale, { hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true });

    // --- جمع وتصنيف الأوامر ---
    const tagCount = {};
    const tagHelpMapping = {};
    const plugins = Object.values(global.plugins).filter(plugin => !plugin.disabled && plugin.help);

    plugins.forEach(plugin => {
        const tagsArray = Array.isArray(plugin.tags) ? plugin.tags : [];
        const helpArray = Array.isArray(plugin.help) ? plugin.help : [plugin.help];

        if (tagsArray.length > 0) {
            tagsArray.forEach(tag => {
                if (tag) {
                    const capitalizedTag = tag.charAt(0).toUpperCase() + tag.slice(1); // جعل أول حرف كبير
                    if (!tagCount[capitalizedTag]) {
                        tagCount[capitalizedTag] = 0;
                        tagHelpMapping[capitalizedTag] = [];
                    }
                    helpArray.forEach(helpItem => {
                        if (helpItem) {
                            tagCount[capitalizedTag]++;
                            // تخزين معلومات الأمر كاملة
                            tagHelpMapping[capitalizedTag].push({
                                help: helpItem,
                                premium: plugin.premium,
                                limit: plugin.limit
                            });
                        }
                    });
                }
            });
        }
    });
    // إزالة التكرارات من كل قسم إذا لزم الأمر (قد يكون الأمر له نفس الاسم ولكن في وسوم مختلفة)
    for (const tag in tagHelpMapping) {
        tagHelpMapping[tag] = tagHelpMapping[tag].filter((item, index, self) =>
            index === self.findIndex((t) => (t.help === item.help))
        );
        // تحديث العدد بعد إزالة التكرار
        tagCount[tag] = tagHelpMapping[tag].length;
    }

    // --- إعداد بيانات القائمة التفاعلية (الأزرار) ---
    let menuRows = Object.keys(tagCount).sort().map(tag => ({
        title: design.tagDescription(tag, tagCount[tag]), // مثل: "أدوات - 5 ميزة"
        description: `عرض أوامر قسم ${tag}`, // وصف إضافي
        rowId: `${usedPrefix + command} ${tag.toLowerCase()}` // الأمر الذي سينفذ عند الضغط
    }));

    const listMessage = {
        text: `${design.header}
${design.greeting(m.pushName || conn.getName(m.sender))}
${design.dateTime(week, date)} - ${time}

${design.botInfo(global.namebot || 'ALINO-BOT-LIVE', global.version, clockString(process.uptime() * 1000), plugins.length, Object.values(global.db.data.users).filter(user => user.registered).length, Object.keys(global.db.data.users).length)}

${design.prompt}`, // النص الرئيسي لقائمة الأزرار
        footer: design.footer(global.wm || 'MOUH-IFBI'),
        title: design.buttonListTitle,
        buttonText: "عرض القائمة", // النص على الزر الرئيسي
        sections: [
            {
                title: design.buttonAllTitle,
                rows: [
                    {
                        title: "عرض كل الأوامر",
                        description: "إظهار جميع الأوامر المتاحة في رسالة واحدة",
                        rowId: `${usedPrefix + command} all`
                    }
                ]
            },
            {
                title: design.buttonSectionTitle,
                rows: menuRows // إضافة أقسام الأوامر هنا
            },
            {
                title: design.buttonInfoTitle,
                rows: [
                    {
                        title: "معلومات المطور",
                        description: "عرض معلومات عن مالك البوت",
                        rowId: `${usedPrefix}owner`
                    },
                    {
                        title: "رابط السكريبت",
                        description: "الحصول على رابط السورس كود الخاص بالبوت",
                        rowId: `${usedPrefix}sc`
                    },
                    {
                        title: "حالة البوت",
                        description: "عرض معلومات عن سرعة واستضافة البوت",
                        rowId: `${usedPrefix}ping` // أو .os حسب الأمر المتاح
                    }
                ]
            }
        ]
    };

    // --- بناء القائمة النصية --- 
    let mpt = clockString(process.uptime() * 1000);
    let name = m.pushName || conn.getName(m.sender);
    let userReg = Object.values(global.db.data.users).filter(user => user.registered).length;
    let tUser = Object.keys(global.db.data.users).length;
    const totalFitur = plugins.length;
    const botVersion = global.version; // افتراض وجود متغير version في global

    let textMenu = `${design.header}
${design.greeting(name)}
${design.dateTime(week, date)} - ${time}

${design.botInfo(global.namebot || 'ALINO-BOT-LIVE', botVersion, mpt, totalFitur, userReg, tUser)}
`;

    // --- تحديد طريقة العرض --- 
    try {
        // الخيار الافتراضي هو قائمة الأزرار إذا كانت مدعومة
        let displayMode = _menu?.button ? 'button' : (_menu?.image ? 'image' : (_menu?.gif ? 'gif' : (_menu?.doc ? 'doc' : 'text'))); // تحديد الأولوية

        // إذا طلب المستخدم قسماً محدداً أو الكل
        if (cmd !== 'list') {
            let selectedTag = cmd === 'all' ? 'all' : Object.keys(tagCount).find(tag => tag.toLowerCase() === cmd.toLowerCase());
            
            if (selectedTag) {
                textMenu += `
*أوامر قسم: ${selectedTag === 'all' ? 'الكل' : selectedTag}*
`;
                if (selectedTag === 'all') {
                    // عرض كل الأقسام
                    Object.keys(tagCount).sort().forEach(tag => {
                        textMenu += `
${design.menuSectionHeader(tag)}
`;
                        tagHelpMapping[tag].forEach(item => {
                            textMenu += `${design.menuItem(item.help, item.premium, item.limit)}
`;
                        });
                        textMenu += `${design.menuSectionFooter}
`;
                    });
                } else {
                    // عرض قسم محدد
                    textMenu += `
${design.menuSectionHeader(selectedTag)}
`;
                    tagHelpMapping[selectedTag].forEach(item => {
                        textMenu += `${design.menuItem(item.help, item.premium, item.limit)}
`;
                    });
                    textMenu += `${design.menuSectionFooter}
`;
                }
                textMenu += `
${design.footer(global.wm || 'MOUH-IFBI')}`;
                // عند طلب قسم محدد أو الكل، الأفضل إرساله كنص عادي لتجنب مشاكل الطول في الأوضاع الأخرى
                displayMode = 'text'; 
            } else {
                return m.reply(`⚠️ القسم "${cmd}" غير موجود. استخدم 
*${usedPrefix + command}* لعرض قائمة الأقسام.`);
            }
        }

        // --- إرسال القائمة حسب الوضع المحدد ---
        const pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg"); // صورة افتراضية
        const thumbnailUrl = global.thumbnail || pp; // استخدام الصورة المصغرة العامة أو صورة المستخدم
        const sourceUrl = global.sgc || 'https://github.com/noureddineouafy/silana-lite-ofc'; // رابط المصدر

        if (displayMode === 'button' && cmd === 'list') {
            // إرسال قائمة الأزرار التفاعلية
            await conn.sendMessage(m.chat, listMessage, { quoted: m });
        } else if (displayMode === 'image' && cmd === 'list') {
            // إرسال القائمة كصورة (استخدام النص المبني مسبقاً كـ caption)
            await conn.sendMessage(m.chat, {
                image: { url: thumbnailUrl },
                caption: textMenu + `
${design.prompt}

` + Object.keys(tagCount).sort().map(tag => `*${usedPrefix + command} ${tag.toLowerCase()}*`).join('\n') + `
*${usedPrefix + command} all*

${design.footer(global.wm || 'MOUH-IFBI')}`,
                contextInfo: {
                    externalAdReply: {
                        title: global.namebot,
                        body: 'قائمة الأوامر',
                        thumbnailUrl: thumbnailUrl,
                        sourceUrl: sourceUrl,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m });
        } else if (displayMode === 'gif' && cmd === 'list') {
            // إرسال القائمة كـ GIF (استخدام النص المبني مسبقاً كـ caption)
            const gifUrl = "https://telegra.ph/file/ca2d038b71ff86e2c70d3.mp4"; // مثال لرابط GIF
            await conn.sendMessage(m.chat, {
                video: { url: gifUrl },
                gifPlayback: true,
                caption: textMenu + `
${design.prompt}

` + Object.keys(tagCount).sort().map(tag => `*${usedPrefix + command} ${tag.toLowerCase()}*`).join('\n') + `
*${usedPrefix + command} all*

${design.footer(global.wm || 'MOUH-IFBI')}`,
                contextInfo: {
                    externalAdReply: {
                        title: global.namebot,
                        body: 'قائمة الأوامر',
                        thumbnailUrl: thumbnailUrl,
                        sourceUrl: sourceUrl,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m });
        } else if (displayMode === 'doc' && cmd === 'list') {
            // إرسال القائمة كمستند (استخدام النص المبني مسبقاً كـ caption)
            await conn.sendMessage(m.chat, {
                document: Buffer.from(''), // يمكن وضع محتوى ملف هنا أو تركه فارغاً
                mimetype: 'application/pdf', // أو أي نوع ملف
                fileName: `${global.namebot} - Menu.pdf`,
                caption: textMenu + `
${design.prompt}

` + Object.keys(tagCount).sort().map(tag => `*${usedPrefix + command} ${tag.toLowerCase()}*`).join('\n') + `
*${usedPrefix + command} all*

${design.footer(global.wm || 'MOUH-IFBI')}`,
                contextInfo: {
                    externalAdReply: {
                        title: global.namebot,
                        body: 'قائمة الأوامر',
                        thumbnailUrl: thumbnailUrl,
                        sourceUrl: sourceUrl,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m });
        } else {
            // الوضع الافتراضي أو عند طلب قسم معين/الكل: إرسال كنص عادي
            await conn.reply(m.chat, textMenu, m);
        }

    } catch (e) {
        console.error(e);
        m.reply('حدث خطأ أثناء إنشاء القائمة.');
    }
};

handler.help = ['menu [قسم]'];
handler.tags = ['main'];
handler.command = /^(menu|help|اوامر|أوامر)$/i; // توسيع نطاق الأوامر
handler.register = false;
export default handler;

// --- دالة تنسيق الوقت ---
function clockString(ms) {
    let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000);
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24;
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
    let parts = [];
    if (d > 0) parts.push(d + ' يوم');
    if (h > 0) parts.push(h + ' ساعة');
    if (m > 0) parts.push(m + ' دقيقة');
    if (s > 0) parts.push(s + ' ثانية');
    return parts.join(', ') || 'الآن'; // إرجاع نص مفهوم
}

