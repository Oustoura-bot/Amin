// kora_apifootball_handler.js - Main handler using API-Football

import { fetchApiFootballFixtures } from "./apifootball_fetcher.js"; // Import the API-Football fetcher
import baileys from "@adiwajshing/baileys";

// --- Cache Configuration ---
let cachedApiFootballData = {
    matches: null,
    lastFetchTime: 0,
    fetchDate: null // Store the date for which data was fetched
};
const CACHE_DURATION = 15 * 60 * 1000; // 15 minutes cache

// --- Data Processing ---
/**
 * @typedef {object} ApiFootballFixture
 * // Structure based on API-Football v3 documentation for /fixtures endpoint
 * @property {object} fixture
 * @property {number} fixture.id
 * @property {string} fixture.date // ISO 8601 date string
 * @property {object} fixture.venue
 * @property {string} fixture.venue.name
 * @property {object} fixture.status
 * @property {string} fixture.status.long
 * @property {string} fixture.status.short
 * @property {number | null} fixture.status.elapsed
 * @property {object} league
 * @property {number} league.id
 * @property {string} league.name
 * @property {string} league.country
 * @property {string} league.logo
 * @property {number} league.season
 * @property {string} league.round
 * @property {object} teams
 * @property {object} teams.home
 * @property {number} teams.home.id
 * @property {string} teams.home.name
 * @property {string} teams.home.logo
 * @property {boolean | null} teams.home.winner
 * @property {object} teams.away
 * @property {number} teams.away.id
 * @property {string} teams.away.name
 * @property {string} teams.away.logo
 * @property {boolean | null} teams.away.winner
 * @property {object} goals
 * @property {number | null} goals.home
 * @property {number | null} goals.away
 * @property {object} score
 * @property {object} score.halftime
 * @property {number | null} score.halftime.home
 * @property {number | null} score.halftime.away
 * @property {object} score.fulltime
 * @property {number | null} score.fulltime.home
 * @property {number | null} score.fulltime.away
 * @property {object} score.extratime
 * @property {number | null} score.extratime.home
 * @property {number | null} score.extratime.away
 * @property {object} score.penalty
 * @property {number | null} score.penalty.home
 * @property {number | null} score.penalty.away
 */

/**
 * @typedef {object} ProcessedMatchData
 * @property {string} id // Unique ID for the match (e.g., api_fixture_id)
 * @property {string} league
 * @property {string} date // Formatted date
 * @property {string} time // Formatted time
 * @property {string} team1
 * @property {string | null} logo1
 * @property {string} team2
 * @property {string | null} logo2
 * @property {string} status // Descriptive status (e.g., "لم تبدأ", "جارية", "انتهت")
 * @property {string} score // Formatted score (e.g., "1 - 0")
 * @property {string | null} venue
 */

/**
 * Processes raw API-Football fixture data.
 * @param {ApiFootballFixture[]} rawFixtures
 * @returns {ProcessedMatchData[]}
 */
function processApiFootballFixtures(rawFixtures) {
    if (!rawFixtures) return [];
    return rawFixtures.map((fixtureData) => {
        const { fixture, league, teams, goals, score } = fixtureData;

        // Format Date and Time (adjust to local timezone if needed, API provides UTC)
        const matchDateTime = new Date(fixture.date);
        const formattedDate = matchDateTime.toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" });
        const formattedTime = matchDateTime.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit", hour12: true });

        // Determine Status
        let displayStatus = fixture.status.long;
        let displayTime = formattedTime;
        switch (fixture.status.short) {
            case "TBD": displayStatus = "لم يحدد بعد"; break;
            case "NS": displayStatus = "لم تبدأ"; break;
            case "1H": displayStatus = `الشوط الأول (${fixture.status.elapsed}")`; displayTime = "-"; break;
            case "HT": displayStatus = "استراحة الشوطين"; displayTime = "-"; break;
            case "2H": displayStatus = `الشوط الثاني (${fixture.status.elapsed}")`; displayTime = "-"; break;
            case "ET": displayStatus = `وقت إضافي (${fixture.status.elapsed}")`; displayTime = "-"; break;
            case "BT": displayStatus = "استراحة الوقت الإضافي"; displayTime = "-"; break;
            case "P": displayStatus = "ركلات الترجيح"; displayTime = "-"; break;
            case "SUSP": displayStatus = "موقوفة"; displayTime = "-"; break;
            case "INT": displayStatus = "توقفت"; displayTime = "-"; break;
            case "FT": displayStatus = "انتهت"; displayTime = "-"; break;
            case "AET": displayStatus = "انتهت (وقت إضافي)"; displayTime = "-"; break;
            case "PEN": displayStatus = "انتهت (ركلات ترجيح)"; displayTime = "-"; break;
            case "PST": displayStatus = "مؤجلة"; break;
            case "CANC": displayStatus = "ألغيت"; break;
            case "ABD": displayStatus = "تُركت"; break;
            case "AWD": displayStatus = "محتسبة"; break;
            case "WO": displayStatus = "انسحاب"; break;
            case "LIVE": displayStatus = "جارية الآن"; displayTime = "-"; break; // Generic live status if specific half/minute isn"t available
        }

        // Format Score
        let displayScore = "-";
        if (goals.home !== null && goals.away !== null) {
            displayScore = `${goals.home} - ${goals.away}`;
        }

        return {
            id: `api_${fixture.id}`,
            league: `${league.name} (${league.country})`,
            date: formattedDate,
            time: displayTime,
            team1: teams.home.name,
            logo1: teams.home.logo,
            team2: teams.away.name,
            logo2: teams.away.logo,
            status: displayStatus,
            score: displayScore,
            venue: fixture.venue.name
        };
    });
}

// --- Data Fetching with Cache ---
async function getProcessedMatchesTodayApiFootball() {
    const todayDateStr = new Date().toISOString().split("T")[0]; // YYYY-MM-DD
    const now = Date.now();

    // Check cache validity (time and date)
    if (cachedApiFootballData.lastFetchTime &&
        (now - cachedApiFootballData.lastFetchTime < CACHE_DURATION) &&
        cachedApiFootballData.fetchDate === todayDateStr &&
        cachedApiFootballData.matches !== null)
    {
        console.log("ℹ️ استخدام بيانات API-Football المخزنة مؤقتًا.");
        return cachedApiFootballData.matches;
    }

    console.log(`ℹ️ جلب بيانات مباريات اليوم (${todayDateStr}) الجديدة من API-Football...`);
    try {
        const rawData = await fetchApiFootballFixtures(todayDateStr);
        const processedData = processApiFootballFixtures(rawData);

        // Update cache
        cachedApiFootballData = {
            matches: processedData,
            lastFetchTime: now,
            fetchDate: todayDateStr
        };
        console.log("✅ تم تحديث بيانات API-Football المخزنة.");
        return processedData;

    } catch (error) {
        console.error("❌ فشل جلب أو معالجة بيانات API-Football:", error);
        // Attempt to return stale cache if available (even from a previous day)
        if (cachedApiFootballData.matches !== null) {
            console.warn("⚠️ فشل التحديث، سيتم استخدام البيانات القديمة إن وجدت.");
            return cachedApiFootballData.matches;
        }
        // If no cache and fetch failed, re-throw
        throw error;
    }
}

// --- Main Handler (Using API-Football Data, No Buttons, Today Only) ---
let handler = async (m, { conn, command, text }) => {
    try {
        // Fetch and process today"s data (uses cache)
        m.reply("⏳ جاري جلب بيانات مباريات اليوم من API-Football...");
        let todayMatches = await getProcessedMatchesTodayApiFootball();

        // --- Command: "مباريات" (List today"s matches as text) ---
        if (command === "مباريات" && !text) {
            if (!todayMatches || todayMatches.length === 0) {
                return conn.sendMessage(m.chat, { text: "ℹ️ لا توجد مباريات متاحة لعرضها اليوم من API-Football." }, { quoted: m });
            }

            let responseText = `🏆 *قائمة مباريات اليوم (${todayMatches[0]?.date || new Date().toLocaleDateString("ar-EG")}) - المصدر: API-Football* 🏆\n\n`;
            todayMatches.forEach((match, index) => {
                responseText += `${index + 1}. ${match.team1} 🆚 ${match.team2} (${match.time !== "-" ? match.time : match.status}) - ${match.league}\n`;
            });
            responseText += "\n";
            responseText += `📌 لعرض تفاصيل مباراة، استخدم الأمر: *.مباراة {رقم_المباراة}*`;

            return conn.sendMessage(m.chat, { text: responseText }, { quoted: m });
        }

        // --- Command: "مباراة" (Show match details as text/image, no buttons) ---
        if (command === "مباراة" && text) {
            if (!todayMatches) { // Ensure matches were fetched
                 return conn.sendMessage(m.chat, { text: "⚠️ لم يتم تحميل بيانات المباريات بعد، يرجى المحاولة مرة أخرى باستخدام الأمر `مباريات` أولاً." }, { quoted: m });
            }
            let index = parseInt(text.trim()) - 1; // User inputs 1-based index

            if (isNaN(index) || index < 0 || index >= todayMatches.length) {
                return conn.sendMessage(m.chat, { text: `⚠️ *المباراة غير موجودة!* الرقم المدخل غير صحيح أو خارج النطاق.` }, { quoted: m });
            }

            let match = todayMatches[index];

            let caption = `🏆 *${match.team1} 🆚 ${match.team2}*\n\n` +
                          `📅 *المسابقة:* ${match.league}\n` +
                          `🏟️ *الملعب:* ${match.venue || "غير محدد"}\n` +
                          `🗓️ *التاريخ:* ${match.date}\n` +
                          `⏰ *الوقت/الحالة:* ${match.time !== "-" ? match.time : match.status}\n` +
                          `⚽ *النتيجة:* ${match.score}\n` +
                          `📌 *الحالة التفصيلية:* ${match.status}`;

            let messageOptions = { caption: caption };
            // Use home team logo as primary image if available
            let logoUrl = match.logo1 || match.logo2;

            if (logoUrl) {
                try {
                    new URL(logoUrl);
                    messageOptions.image = { url: logoUrl };
                } catch (e) {
                    console.warn(`Invalid logo URL for match ${match.id}: ${logoUrl}`);
                    messageOptions.text = caption;
                    delete messageOptions.caption;
                }
            } else {
                messageOptions.text = caption;
                delete messageOptions.caption;
            }

            return conn.sendMessage(m.chat, messageOptions, { quoted: m });
        }

    } catch (error) {
        console.error("❌ خطأ في معالج أوامر API-Football:", error);
        let errorMessage = `⚠️ حدث خطأ أثناء جلب أو عرض بيانات المباريات من API-Football.
(${error.message})`;
        // Check for specific API key related errors
        if (error.message.includes("Invalid API key") || error.message.includes("خطأ مصادقة")) {
            errorMessage = "⚠️ خطأ في مفتاح API-Football. يرجى التأكد من صحة المفتاح أو التحقق من حالة اشتراكك.";
        } else if (error.message.includes("limit")) {
            errorMessage = "⚠️ تم تجاوز حد الطلبات اليومي لخطة API-Football المجانية (100 طلب). يرجى المحاولة غدًا.";
        }
        return conn.sendMessage(m.chat, { text: errorMessage }, { quoted: m });
    }
};

// --- Bot Command Configuration ---
handler.command = ["مباريات", "مباراة"];
handler.help = ["مباريات", "مباراة"];
handler.tags = ["sports", "tools", "apifootball"];
handler.limit = false;
handler.private = false;

export default handler;

